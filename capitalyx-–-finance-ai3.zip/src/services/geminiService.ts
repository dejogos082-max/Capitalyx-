
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { Transaction, AIAnalysisResult, FinancialGoal, TransactionType, AIProvider } from "../types";
import { getAIConfig } from "./firebase";
import { OpenAIConfig } from "./openAIService";

// --- Configuration & Helpers ---

const cleanJsonString = (rawString: string): string => {
  let cleaned = rawString.trim();
  // Regex para extrair JSON de blocos de código markdown
  const jsonBlockRegex = /```(?:json)?\s*([\s\S]*?)\s*```/i;
  const match = cleaned.match(jsonBlockRegex);
  
  if (match && match[1]) {
    cleaned = match[1].trim();
  }
  
  return cleaned;
};

const callActiveAIProvider = async (prompt: string, provider: AIProvider): Promise<string> => {
    switch (provider) {
        case 'openai':
            const oaResult = await OpenAIConfig.execute([{ role: 'user', content: prompt }]);
            return oaResult.choices?.[0]?.message?.content || "";
        case 'gemini':
        default:
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const response = await ai.models.generateContent({
                model: 'gemini-3-flash-preview',
                contents: prompt,
                config: {
                    responseMimeType: "application/json"
                }
            });
            return response.text || "";
    }
};

// --- INTERNAL: Gemini Specific Implementation ---

const runGeminiAnalysis = async (prompt: string): Promise<AIAnalysisResult> => {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    const response: GenerateContentResponse = await ai.models.generateContent({
        model: 'gemini-3-flash-preview', 
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    summary: { type: Type.STRING },
                    savingsTip: { type: Type.STRING },
                    alert: { type: Type.STRING, nullable: true },
                    prediction: { type: Type.STRING },
                    cashFlowTip: { type: Type.STRING },
                    investmentTip: { type: Type.STRING },
                    spendingHabit: { type: Type.STRING },
                    suggestedGoals: {
                        type: Type.ARRAY,
                        items: {
                            type: Type.OBJECT,
                            properties: {
                                title: { type: Type.STRING },
                                targetAmount: { type: Type.NUMBER },
                                deadline: { type: Type.STRING }
                            },
                            required: ["title", "targetAmount", "deadline"]
                        }
                    }
                },
                required: ["summary", "savingsTip", "prediction", "cashFlowTip", "suggestedGoals"]
            }
        }
    });

    const text = response.text;
    if (!text) throw new Error("Gemini retornou resposta vazia");
    
    const cleanText = cleanJsonString(text);
    const result = JSON.parse(cleanText) as AIAnalysisResult;
    return { ...result, analyzedAt: Date.now() };
};

export interface CategoryAnalysisResult {
    analysis: string;
    keyFactors: string[];
    optimizationStrategy: string;
}

export const generateCategoryInsights = async (
    transactions: Transaction[], 
    viewType: 'balance' | 'income' | 'expense'
): Promise<CategoryAnalysisResult> => {
    
    const aiConfig = await getAIConfig();
    const provider = aiConfig.activeProvider || 'gemini';
    
    const simpleTx = transactions.map(t => ({
        d: t.date, v: t.amount, c: t.category, desc: t.description
    }));

    let promptContext = "";
    if (viewType === 'income') promptContext = "Foque nas fontes de renda. Identifique estabilidade, diversificação e oportunidades de renda extra.";
    if (viewType === 'expense') promptContext = "Foque nos gastos. Identifique gargalos, gastos supérfluos (wants vs needs) e onde cortar imediatamente.";
    if (viewType === 'balance') promptContext = "Analise o fluxo líquido (Net Flow). O usuário está solvente? Qual a taxa de queima (burn rate)? Como otimizar a sobra?";

    const prompt = `
        Aja como um consultor financeiro de elite (Capitalyx AI).
        Analise estas transações do tipo [${viewType.toUpperCase()}]: ${JSON.stringify(simpleTx)}.
        ${promptContext}
        
        Responda ESTRITAMENTE um JSON:
        {
            "analysis": "Uma análise profunda e detalhada de 2 parágrafos sobre este cenário.",
            "keyFactors": ["Fator 1", "Fator 2", "Fator 3", "Fator 4"],
            "optimizationStrategy": "Uma estratégia prática e acionável para melhorar este aspecto financeiro."
        }
    `;

    try {
        const text = await callActiveAIProvider(prompt, provider);
        return JSON.parse(cleanJsonString(text)) as CategoryAnalysisResult;
    } catch (e) {
        console.error(`Category Analysis Failed with ${provider}`, e);
        return {
            analysis: "Não foi possível gerar a análise detalhada no momento.",
            keyFactors: ["Dados insuficientes"],
            optimizationStrategy: "Tente novamente mais tarde."
        };
    }
};

export const generateAIOnlyGoals = async (transactions: Transaction[]): Promise<FinancialGoal[]> => {
    const aiConfig = await getAIConfig();
    const provider = aiConfig.activeProvider || 'gemini';

    const prompt = `
        Com base nestas transações recentes: ${JSON.stringify(transactions.slice(0, 30))},
        Gere uma lista de 5 a 10 metas financeiras inteligentes (SMART goals) altamente personalizadas em PT-BR.
        Foque em: Reserva de Emergência, Aposentadoria, Viagens ou redução de dívidas se houver.
        
        Retorne JSON seguindo este formato exato: { "goals": [{ "title": "string", "targetAmount": number, "deadline": "YYYY-MM-DD" }] }
    `;

    try {
        const text = await callActiveAIProvider(prompt, provider);
        const data = JSON.parse(cleanJsonString(text));
        return data.goals || [];
    } catch (e) {
        console.error(`Goal Gen Failed with ${provider}`, e);
        return [];
    }
};

export const generateFinancialInsights = async (
  transactions: Transaction[], 
  goals: FinancialGoal[] = []
): Promise<AIAnalysisResult> => {
  
  if (transactions.length === 0 && goals.length === 0) {
    return {
      summary: "Sem dados suficientes para análise.",
      savingsTip: "Adicione transações para receber dicas personalizadas.",
      alert: null,
      prediction: "Aguardando dados...",
      cashFlowTip: "Adicione receitas e despesas.",
      suggestedGoals: []
    };
  }

  const sortedTransactions = [...transactions].sort((a, b) => 
    new Date(b.date).getTime() - new Date(a.date).getTime()
  );

  const simpleTransactions = sortedTransactions.slice(0, 50).map(t => ({
    d: t.date, v: t.amount, t: t.type, c: t.category, desc: t.description
  }));

  const simpleGoals = goals.map(g => ({
    title: g.title, curr: g.currentAmount, target: g.targetAmount, dl: g.deadline
  }));

  const prompt = `
    Analise os dados financeiros JSON abaixo e forneça insights estratégicos profundos em PT-BR.
    Seja criativo, direto e evite jargões complexos sem explicação.
    
    DADOS:
    Transações: ${JSON.stringify(simpleTransactions)}
    Metas: ${JSON.stringify(simpleGoals)}
    
    Retorne ESTRITAMENTE um JSON com estas chaves exatas:
    {
      "summary": "Resumo executivo do momento financeiro atual (max 300 caracteres).",
      "savingsTip": "Uma dica tática de economia imediata.",
      "investmentTip": "Uma sugerão de alocação ou oportunidade baseada no saldo livre.",
      "spendingHabit": "Uma observação sobre um hábito de gasto recorrente (ex: muito iFood, Uber, etc).",
      "alert": "Alerta curto de risco (ou null se tudo ok).",
      "prediction": "Previsão de saldo para o fim do mês.",
      "cashFlowTip": "Dica para melhorar o fluxo de caixa.",
      "suggestedGoals": [{"title": "...", "targetAmount": 0, "deadline": "YYYY-MM-DD"}]
    }
  `;

  const aiConfig = await getAIConfig();
  const provider = aiConfig.activeProvider || 'gemini';

  console.log(`[AI Orchestrator] Routing request to: ${provider.toUpperCase()}`);

  let result: AIAnalysisResult;

  try {
      if (provider === 'openai') {
          result = await OpenAIConfig.generateAnalysis(prompt);
      } else {
          result = await runGeminiAnalysis(prompt);
      }
      
      return { ...result, providerUsed: provider };

  } catch (error: any) {
      const errorMsg = error instanceof Error ? error.message : String(error);
      
      if (errorMsg.includes("QUOTA_EXCEEDED") || errorMsg.includes("402") || errorMsg.includes("429")) {
          console.warn(`[AI Orchestrator] Provider ${provider} quota exceeded. Switching to backup Gemini.`);
      } else {
          console.error(`[AI Orchestrator] Provider ${provider} Failed:`, errorMsg);
      }
      
      if (provider !== 'gemini') {
          try {
              const fallbackResult = await runGeminiAnalysis(prompt);
              return {
                  ...fallbackResult,
                  alert: fallbackResult.alert 
                    ? `${fallbackResult.alert} (Nota: Usando Gemini por fallback)` 
                    : `Nota: Usando Gemini (Fallback)`,
                  providerUsed: 'gemini'
              };
          } catch (fbError) {
              console.error("[AI Orchestrator] Fallback also failed.", fbError);
          }
      }

      return {
        summary: "Não foi possível processar a análise inteligente no momento.",
        savingsTip: "Verifique sua conexão ou tente mais tarde.",
        alert: "Erro de Conexão AI",
        prediction: "Indisponível",
        cashFlowTip: "Sistema indisponível.",
        suggestedGoals: [],
        providerUsed: provider
      };
  }
};
