
import React from 'react';
import { UserProfile, AppSettings } from '../types';
import { auth } from '../services/firebase';
import { sendOptimizedVerificationEmail, getVerificationCooldownRemaining } from '../services/authOptimized';
import { 
  LayoutDashboard, 
  Wallet, 
  LogOut, 
  TrendingUp, 
  PieChart, 
  Menu,
  X,
  MailWarning,
  Award,
  Target,
  Settings,
  User,
  Shield,
  Loader2,
  ArrowLeft,
  TestTube2,
  Sparkles
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface LayoutProps {
  children: React.ReactNode;
  user: UserProfile;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  settings: AppSettings;
  onLogout: () => void;
  onUpdateSettings?: (settings: AppSettings) => void;
}

const Layout: React.FC<LayoutProps> = ({ children, user, activeTab, setActiveTab, settings, onLogout, onUpdateSettings }) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);
  const [verificationStatus, setVerificationStatus] = React.useState<'idle' | 'sending' | 'sent' | 'error'>('idle');
  const [statusMessage, setStatusMessage] = React.useState('');
  const [cooldown, setCooldown] = React.useState(0);

  React.useEffect(() => {
     const remaining = getVerificationCooldownRemaining();
     if (remaining > 0) setCooldown(remaining);
  }, []);

  React.useEffect(() => {
      let interval: any;
      if (cooldown > 0) {
          interval = setInterval(() => {
              setCooldown(prev => prev <= 1 ? 0 : prev - 1);
          }, 1000);
      }
      return () => clearInterval(interval);
  }, [cooldown]);

  const navItems = [
    { id: 'dashboard', label: 'Visão Geral', icon: LayoutDashboard },
    { id: 'transactions', label: 'Transações', icon: Wallet },
    { id: 'goals', label: 'Metas', icon: Target },
    { id: 'analytics', label: 'Insights AI', icon: PieChart },
    { id: 'achievements', label: 'Conquistas', icon: Award },
    { id: 'profile', label: 'Meu Perfil', icon: User },
    { id: 'settings', label: 'Configurações', icon: Settings },
  ];

  if (user.isAdministrator) {
    navItems.push({ id: 'admin', label: 'Painel Admin', icon: Shield });
  }

  const handleResendVerification = async () => {
    if (!auth.currentUser) return;
    setVerificationStatus('sending');
    try {
        const result = await sendOptimizedVerificationEmail(auth.currentUser);
        if (result.success) {
            setVerificationStatus('sent');
            setStatusMessage(result.message);
            setCooldown(60);
        } else {
            setVerificationStatus('error');
            setStatusMessage(result.message);
            if (result.remainingTime) setCooldown(result.remainingTime);
        }
    } catch (error) {
        setVerificationStatus('error');
        setStatusMessage("Erro inesperado.");
    }
  };

  const handleToggleBeta = () => {
    if (onUpdateSettings) {
      onUpdateSettings({
        ...settings,
        account: { ...settings.account, betaMode: !settings.account.betaMode }
      });
    }
  };

  const isBeta = settings.account.betaMode;

  // --- COMPONENTE BETA SWITCH PREMIUM ---
  const BetaSwitch = ({ size = "md" }: { size?: "sm" | "md" }) => (
    <button 
      onClick={handleToggleBeta}
      className={`relative flex items-center group outline-none transition-all ${size === "sm" ? "gap-1.5" : "gap-2"}`}
      title={isBeta ? "Desativar Modo Beta" : "Ativar Modo Beta"}
    >
      <div className="relative flex items-center">
        {/* Background do Switch */}
        <motion.div 
          animate={{ 
            backgroundColor: isBeta ? "rgba(99, 102, 241, 0.2)" : "rgba(30, 41, 59, 0.5)",
            borderColor: isBeta ? "rgba(129, 140, 248, 0.5)" : "rgba(71, 85, 105, 0.3)"
          }}
          className={`
            ${size === "sm" ? "w-10 h-5" : "w-11 h-6"} 
            rounded-full border backdrop-blur-sm relative transition-colors duration-500
          `}
        >
          {/* Knob */}
          <motion.div 
            layout
            transition={{ type: "spring", stiffness: 500, damping: 30 }}
            animate={{ x: isBeta ? (size === "sm" ? 20 : 22) : 2 }}
            className={`
              ${size === "sm" ? "w-3.5 h-3.5" : "w-4.5 h-4.5"} 
              rounded-full bg-white shadow-lg absolute top-0.5 flex items-center justify-center overflow-hidden
            `}
          >
             {isBeta && (
               <motion.div 
                initial={{ opacity: 0, scale: 0.5 }}
                animate={{ opacity: 1, scale: 1 }}
                className="text-indigo-500"
               >
                 <Sparkles size={8} fill="currentColor" />
               </motion.div>
             )}
          </motion.div>
        </motion.div>

        {/* Efeito Glow quando ativo */}
        <AnimatePresence>
          {isBeta && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              className="absolute inset-0 rounded-full bg-indigo-500/20 blur-md -z-10"
            />
          )}
        </AnimatePresence>
      </div>

      <div className="flex flex-col items-start leading-none">
        <div className="flex items-center gap-1">
          <TestTube2 
            size={size === "sm" ? 12 : 14} 
            className={`transition-colors duration-500 ${isBeta ? "text-indigo-400" : "text-slate-500"}`} 
          />
          <span className={`text-[10px] font-bold uppercase tracking-tighter transition-colors duration-500 ${isBeta ? "text-indigo-300" : "text-slate-500"}`}>
            Beta
          </span>
        </div>
      </div>
    </button>
  );

  const getThemeBackground = () => {
    switch (settings.visual.theme) {
      case 'cyberpunk': return 'bg-[#05050a]';
      case 'ocean': return 'bg-[#0f172a]'; 
      case 'sunset': return 'bg-[#180808]'; 
      default: return 'bg-background'; 
    }
  };

  const getThemeAccent = (isActive: boolean, isDanger?: boolean) => {
    if (isDanger && isActive) return 'bg-rose-900/30 text-rose-400 font-medium shadow-lg border border-rose-500/20';
    switch (settings.visual.theme) {
      case 'cyberpunk': return isActive ? 'bg-fuchsia-900/30 text-fuchsia-400' : 'text-muted hover:bg-slate-800/50';
      case 'ocean': return isActive ? 'bg-cyan-900/30 text-cyan-400' : 'text-muted hover:bg-slate-800/50';
      case 'sunset': return isActive ? 'bg-orange-900/30 text-orange-400' : 'text-muted hover:bg-slate-800/50';
      default: return isActive ? 'bg-primary/20 text-primary' : 'text-muted hover:bg-slate-700/50';
    }
  };

  const getLogoGradient = () => {
    switch (settings.visual.theme) {
      case 'cyberpunk': return 'bg-gradient-to-tr from-fuchsia-600 to-purple-600';
      case 'ocean': return 'bg-gradient-to-tr from-cyan-500 to-blue-600';
      case 'sunset': return 'bg-gradient-to-tr from-orange-500 to-red-600';
      default: return 'bg-gradient-to-tr from-primary to-secondary';
    }
  };

  return (
    <div 
      className={`flex h-screen ${getThemeBackground()} overflow-hidden text-slate-100 transition-colors duration-500`}
      style={{ transform: `scale(${settings.visual.scale})`, transformOrigin: 'top left', width: `${100 / settings.visual.scale}%`, height: `${100 / settings.visual.scale}%` }}
    >
      {/* Sidebar Desktop */}
      <aside className={`hidden md:flex w-64 flex-col bg-surface z-10 border-r border-slate-700`}>
        <div className="p-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-lg ${getLogoGradient()}`}>
              <TrendingUp size={24} className="text-white" />
            </div>
            <span className="text-xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white to-slate-400">
              Capitalyx
            </span>
          </div>
        </div>

        <nav className="flex-1 px-4 py-4 space-y-2">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${getThemeAccent(activeTab === item.id, item.id === 'admin')}`}
            >
              <item.icon size={20} />
              {item.label}
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-slate-700">
          {/* Beta Switch Desktop */}
          {settings.visual.showHeaderBetaSwitch && (
            <div className="mb-6 px-2 flex justify-center">
              <BetaSwitch />
            </div>
          )}

          <div 
            className="flex items-center gap-3 mb-4 px-2 cursor-pointer hover:bg-slate-700/30 p-2 rounded-lg transition-colors"
            onClick={() => setActiveTab('profile')}
          >
            <img src={user.photoURL || `https://ui-avatars.com/api/?name=${user.displayName}`} alt="User" className="w-10 h-10 rounded-full border-2 border-slate-600 object-cover" />
            <div className="flex-1 overflow-hidden">
              <p className="text-sm font-medium truncate flex items-center gap-1">{user.displayName} {user.isAdministrator && <Shield size={12} className="text-rose-500 fill-rose-500/20"/>}</p>
              <p className="text-xs text-muted truncate">{user.emailVerified ? 'Verificado' : 'Não Verificado'}</p>
            </div>
          </div>
          <button onClick={onLogout} className="w-full flex items-center justify-center gap-2 text-sm text-danger hover:bg-danger/10 py-2 rounded-lg transition-colors">
            <LogOut size={16} /> Sair
          </button>
        </div>
      </aside>

      {/* Mobile Header */}
      <div className={`md:hidden px-4 py-3 flex justify-between items-center fixed top-0 w-full z-50 bg-surface/90 backdrop-blur-md border-b border-slate-700`}>
         <div className="flex items-center gap-2">
            <div className={`p-1.5 rounded-md ${getLogoGradient()}`}>
                <TrendingUp size={18} className="text-white" />
            </div>
            <span className="font-bold text-lg">Capitalyx</span>
         </div>
        
        <div className="flex items-center gap-4">
            {settings.visual.showHeaderBetaSwitch && <BetaSwitch size="sm" />}
            <button onClick={() => setActiveTab('profile')} className="relative p-0.5 rounded-full border border-slate-600 overflow-hidden active:scale-95 transition-transform">
               <img src={user.photoURL || `https://ui-avatars.com/api/?name=${user.displayName}`} alt="Perfil" className="w-7 h-7 rounded-full object-cover" />
            </button>
            <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="p-2 text-slate-300">
              {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
        </div>
      </div>

      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }} 
            animate={{ opacity: 1, y: 0 }} 
            exit={{ opacity: 0, y: -20 }} 
            className="fixed inset-0 top-16 z-40 bg-background md:hidden p-4"
            // Stop propagation to ensure clicks inside menu don't leak, though pointer-events-none on main is the primary fix
            onClick={(e) => e.stopPropagation()} 
          >
             <nav className="space-y-2">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => { setActiveTab(item.id); setIsMobileMenuOpen(false); }}
                  className={`w-full flex items-center gap-3 px-4 py-4 rounded-xl text-lg ${getThemeAccent(activeTab === item.id, item.id === 'admin')}`}
                >
                  <item.icon size={24} /> {item.label}
                </button>
              ))}
            </nav>
          </motion.div>
        )}
      </AnimatePresence>

      <main 
        className={`flex-1 overflow-y-auto pt-16 md:pt-0 relative flex flex-col z-10 
        ${isMobileMenuOpen ? 'pointer-events-none touch-none overflow-hidden blur-[1px] opacity-50' : ''} transition-all duration-300`}
      >
        <AnimatePresence>
          {!user.emailVerified && user.email && (
            <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} className="bg-orange-500/10 border-b border-orange-500/20 px-4 py-3 pointer-events-auto">
              <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <MailWarning className="text-orange-400 shrink-0" size={20} />
                  <p className="text-sm text-orange-100">Verifique seu e-mail ({user.email}) para desbloquear todas as funções.</p>
                </div>
                <button onClick={handleResendVerification} disabled={verificationStatus === 'sending' || cooldown > 0} className="text-xs bg-orange-500 hover:bg-orange-600 text-white px-3 py-1.5 rounded-lg font-medium transition-colors disabled:opacity-50">
                    {cooldown > 0 ? `Aguarde ${cooldown}s` : 'Reenviar Link'}
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
        <div className="p-4 md:p-8 flex-1">
          <div className="max-w-6xl mx-auto h-full">
            {children}
          </div>
        </div>
      </main>
    </div>
  );
};

export default Layout;
