
import React, { useState, useEffect } from 'react';
import { TransactionType } from '../types';
import { X, Check, Repeat, PlusCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface TransactionFormProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: any) => void;
  isBetaMode?: boolean; 
  customCategories?: string[]; 
  onAddCustomCategory?: (cat: string) => void; 
  initialDate?: string; // NEW prop
}

const DEFAULT_CATEGORIES = [
  "Salário", "Freelance", "Pix", "Investimentos", // Income
  "Alimentação", "Moradia", "Transporte", "Lazer", "Saúde", "Educação", "Contas" // Expense
];

const TransactionForm: React.FC<TransactionFormProps> = ({ 
  isOpen, onClose, onSubmit, isBetaMode = false, customCategories = [], onAddCustomCategory, initialDate
}) => {
  const [type, setType] = useState<TransactionType>(TransactionType.EXPENSE);
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState(DEFAULT_CATEGORIES[4]);
  const [date, setDate] = useState(initialDate || new Date().toISOString().split('T')[0]);
  
  // Update date if initialDate changes (e.g. reopening form with different date)
  useEffect(() => {
      if (initialDate) {
          setDate(initialDate);
      } else {
          setDate(new Date().toISOString().split('T')[0]);
      }
  }, [initialDate, isOpen]); // Reset on open

  // Beta States
  const [isRecurring, setIsRecurring] = useState(false);
  const [newCategory, setNewCategory] = useState('');
  const [isAddingCategory, setIsAddingCategory] = useState(false);

  // Merge default with custom
  const allCategories = [...DEFAULT_CATEGORIES, ...customCategories];

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || !description) return;
    
    // Check if user is adding a new cat but forgot to hit add button
    let finalCategory = category;
    
    onSubmit({
      description,
      amount: parseFloat(amount),
      type,
      category: finalCategory,
      date,
      isRecurring, // Passed to parent to handle logic
      dayOfMonth: isRecurring ? new Date(date).getDate() : undefined
    });
    
    // Reset
    setDescription('');
    setAmount('');
    setIsRecurring(false);
    onClose();
  };

  const handleAddCategory = () => {
      if (newCategory && onAddCustomCategory) {
          onAddCustomCategory(newCategory);
          setCategory(newCategory); // Auto select
          setNewCategory('');
          setIsAddingCategory(false);
      }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="bg-surface w-full max-w-md rounded-2xl border border-slate-700 shadow-2xl overflow-hidden"
      >
        <div className="flex justify-between items-center p-6 border-b border-slate-700">
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
              Nova Transação 
              {isBetaMode && <span className="text-[10px] bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded border border-indigo-500/30">BETA</span>}
          </h2>
          <button onClick={onClose} className="text-slate-400 hover:text-white transition-colors">
            <X size={24} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {/* Type Toggle */}
          <div className="grid grid-cols-2 gap-2 bg-slate-900 p-1 rounded-xl">
            <button
              type="button"
              onClick={() => setType(TransactionType.INCOME)}
              className={`py-2 rounded-lg text-sm font-medium transition-all ${
                type === TransactionType.INCOME 
                  ? 'bg-emerald-600 text-white shadow-lg' 
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Receita
            </button>
            <button
              type="button"
              onClick={() => setType(TransactionType.EXPENSE)}
              className={`py-2 rounded-lg text-sm font-medium transition-all ${
                type === TransactionType.EXPENSE 
                  ? 'bg-rose-600 text-white shadow-lg' 
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Despesa
            </button>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-400 mb-2">Valor (R$)</label>
            <input
              type="number"
              step="0.01"
              required
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-3 text-lg font-semibold text-white focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all"
              placeholder="0,00"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-400 mb-2">Descrição</label>
            <input
              type="text"
              required
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-3 text-slate-200 focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all"
              placeholder="Ex: Pagamento Freelance"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
             <div>
              <label className="block text-sm font-medium text-slate-400 mb-2">Categoria</label>
              
              {!isAddingCategory ? (
                  <div className="flex gap-2">
                     <select
                        value={category}
                        onChange={(e) => setCategory(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-3 text-slate-200 focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all appearance-none"
                    >
                        {allCategories.map(c => <option key={c} value={c}>{c}</option>)}
                    </select>
                    {isBetaMode && (
                        <button 
                            type="button" 
                            onClick={() => setIsAddingCategory(true)}
                            className="bg-slate-800 border border-slate-700 rounded-lg p-3 text-indigo-400 hover:bg-slate-700"
                            title="Nova Categoria"
                        >
                            <PlusCircle size={20} />
                        </button>
                    )}
                  </div>
              ) : (
                  <div className="flex gap-2">
                      <input 
                        type="text"
                        value={newCategory}
                        onChange={(e) => setNewCategory(e.target.value)}
                        className="w-full bg-indigo-900/20 border border-indigo-500/50 rounded-lg px-2 py-3 text-white text-sm focus:outline-none"
                        placeholder="Nome da categoria"
                        autoFocus
                      />
                      <button 
                        type="button"
                        onClick={handleAddCategory}
                        className="bg-indigo-600 text-white rounded-lg p-2"
                      >
                          <Check size={18} />
                      </button>
                       <button 
                        type="button"
                        onClick={() => setIsAddingCategory(false)}
                        className="bg-slate-800 text-slate-400 rounded-lg p-2"
                      >
                          <X size={18} />
                      </button>
                  </div>
              )}
            </div>
             <div>
              <label className="block text-sm font-medium text-slate-400 mb-2">Data</label>
              <input
                type="date"
                required
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-3 text-slate-200 focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all"
              />
            </div>
          </div>

          {/* BETA: Recurring Toggle */}
          {isBetaMode && (
              <div 
                className={`p-4 rounded-xl border transition-all cursor-pointer ${isRecurring ? 'bg-indigo-900/20 border-indigo-500/50' : 'bg-slate-900 border-slate-700 hover:border-slate-600'}`}
                onClick={() => setIsRecurring(!isRecurring)}
              >
                  <div className="flex items-center gap-3">
                      <div className={`p-2 rounded-lg ${isRecurring ? 'bg-indigo-600 text-white' : 'bg-slate-800 text-slate-500'}`}>
                          <Repeat size={20} />
                      </div>
                      <div>
                          <p className={`font-bold ${isRecurring ? 'text-indigo-300' : 'text-slate-400'}`}>Pagamento Recorrente</p>
                          <p className="text-xs text-slate-500">
                              {isRecurring 
                                ? `Será adicionado automaticamente todo dia ${new Date(date).getDate()}` 
                                : 'Repetir mensalmente (Salário, Aluguel...)'}
                          </p>
                      </div>
                      {isRecurring && <Check size={20} className="ml-auto text-indigo-400" />}
                  </div>
              </div>
          )}

          <button
            type="submit"
            className="w-full bg-gradient-to-r from-primary to-blue-600 hover:from-blue-600 hover:to-primary text-white font-bold py-4 rounded-xl shadow-lg shadow-blue-500/20 transition-all active:scale-95 flex justify-center items-center gap-2 mt-4"
          >
            <Check size={20} />
            {isRecurring ? 'Salvar Regra Recorrente' : 'Salvar Transação'}
          </button>
        </form>
      </motion.div>
    </div>
  );
};

export default TransactionForm;
