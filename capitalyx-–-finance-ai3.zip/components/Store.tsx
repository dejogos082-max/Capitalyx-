
import React, { useState, useEffect } from 'react';
import { UserProfile } from '../types';
import { updateStoreBalance, subscribeToStoreBalance, updateUserProfileData } from '../services/firebase';
import { 
  ShoppingBag, Wallet, Plus, ArrowUpRight, ArrowDownLeft, 
  Sparkles, ShieldCheck, Zap, Crown, Check, Loader2,
  CreditCard, Monitor, Palette, Coins, RefreshCw
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface StoreProps {
  user: UserProfile;
  onShowToast: (message: string, type: 'success' | 'error' | 'info') => void;
}

const STORE_ITEMS = [
  { 
    id: 1, 
    name: 'Consultoria AI Pro', 
    price: 150.00, 
    icon: Sparkles, 
    color: 'bg-indigo-500', 
    desc: 'Análise financeira profunda com IA avançada.' 
  },
  { 
    id: 2, 
    name: 'Tema Cyberpunk', 
    price: 50.00, 
    icon: Palette, 
    color: 'bg-fuchsia-500', 
    desc: 'Desbloqueie o tema visual Cyberpunk exclusivo.' 
  },
  { 
    id: 3, 
    name: 'Remover Anúncios', 
    price: 200.00, 
    icon: ShieldCheck, 
    color: 'bg-emerald-500', 
    desc: 'Experiência limpa e sem interrupções vitalícia.' 
  },
  { 
    id: 4, 
    name: 'Pacote de Ícones', 
    price: 25.00, 
    icon: Zap, 
    color: 'bg-orange-500', 
    desc: 'Personalize suas categorias com novos ícones.' 
  },
  { 
    id: 5, 
    name: 'Dashboard Desktop', 
    price: 100.00, 
    icon: Monitor, 
    color: 'bg-blue-500', 
    desc: 'Acesso antecipado ao layout avançado desktop.' 
  },
  { 
    id: 6, 
    name: 'Badge Apoiador', 
    price: 500.00, 
    icon: Crown, 
    color: 'bg-yellow-500', 
    desc: 'Distintivo dourado no seu perfil de usuário.' 
  }
];

const Store: React.FC<StoreProps> = ({ user, onShowToast }) => {
  const [loading, setLoading] = useState(false);
  const [modalOpen, setModalOpen] = useState<'add' | 'withdraw' | null>(null);
  const [amountInput, setAmountInput] = useState('');
  
  // Estado local para gerenciar o saldo com Realtime Listener direto
  const [currentBalance, setCurrentBalance] = useState(user.storeBalance || 0);

  // Escuta diretamente o nó do saldo no Firebase para atualizações instantâneas e confiáveis
  useEffect(() => {
    if (!user.uid) return;
    const unsubscribe = subscribeToStoreBalance(user.uid, (newVal) => {
        setCurrentBalance(newVal);
    });
    return () => unsubscribe();
  }, [user.uid]);

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val);
  };

  const handleTransaction = async () => {
    if (!amountInput || isNaN(parseFloat(amountInput)) || parseFloat(amountInput) <= 0) {
        onShowToast("Digite um valor válido.", 'error');
        return;
    }
    
    setLoading(true);
    const value = parseFloat(amountInput);
    
    try {
        let newBalance = currentBalance;
        
        if (modalOpen === 'add') {
            newBalance += value;
            onShowToast(`R$ ${value} adicionados com sucesso!`, 'success');
        } else if (modalOpen === 'withdraw') {
            if (value > currentBalance) {
                onShowToast("Saldo insuficiente para retirada.", 'error');
                setLoading(false);
                return;
            }
            newBalance -= value;
            onShowToast(`R$ ${value} retirados para sua conta.`, 'success');
        }

        // Atualiza no banco (o listener irá atualizar a UI automaticamente assim que confirmar)
        await updateStoreBalance(user.uid, newBalance);
        setModalOpen(null);
        setAmountInput('');
    } catch (e) {
        console.error(e);
        onShowToast("Erro na transação. Tente novamente.", 'error');
    } finally {
        setLoading(false);
    }
  };

  const handlePurchase = async (item: typeof STORE_ITEMS[0]) => {
      // Verificação segura se badges é array
      const hasSupporterBadge = Array.isArray(user.badges) && user.badges.includes('supporter');

      // Verifica se já possui o item único (Badge Apoiador)
      if (item.id === 6 && hasSupporterBadge) {
          onShowToast("Você já é um Apoiador!", 'info');
          return;
      }

      if (currentBalance < item.price) {
          onShowToast("Saldo insuficiente para esta compra.", 'error');
          return;
      }

      if (confirm(`Confirmar compra de "${item.name}" por ${formatCurrency(item.price)}?`)) {
          setLoading(true);
          try {
              const newBalance = currentBalance - item.price;
              
              // Se for a Badge Apoiador (ID 6), atualiza o perfil
              if (item.id === 6) {
                  // Garante que currentBadges seja um array válido
                  const currentBadges = Array.isArray(user.badges) ? user.badges : [];
                  await updateUserProfileData(user.uid, {
                      badges: [...currentBadges, 'supporter']
                  });
              }

              await updateStoreBalance(user.uid, newBalance);
              onShowToast(`Compra de "${item.name}" realizada!`, 'success');
          } catch (e) {
              console.error(e);
              onShowToast("Erro ao processar compra.", 'error');
          } finally {
              setLoading(false);
          }
      }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8 pb-20">
      
      {/* Header */}
      <div className="flex items-center gap-4">
         <div className="p-3 bg-indigo-500/20 rounded-2xl border border-indigo-500/30">
            <ShoppingBag size={28} className="text-indigo-400" />
         </div>
         <div>
             <h2 className="text-2xl font-bold text-white">Loja Virtual</h2>
             <p className="text-slate-400 text-sm">Gerencie seu saldo e adquira itens exclusivos.</p>
         </div>
      </div>

      {/* Widgets de Saldo */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          
          {/* Card Principal: Saldo */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="md:col-span-1 bg-gradient-to-br from-indigo-900 to-slate-900 p-6 rounded-3xl border border-indigo-500/30 relative overflow-hidden shadow-xl"
          >
              <div className="absolute top-0 right-0 p-6 opacity-10">
                  <Wallet size={100} className="text-white" />
              </div>
              <div className="relative z-10">
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-indigo-300 font-bold text-xs uppercase tracking-widest">Seu Saldo Disponível</p>
                  </div>
                  <h3 className="text-4xl font-bold text-white mb-4">{formatCurrency(currentBalance)}</h3>
                  <div className="flex gap-2">
                      <button 
                        onClick={() => setModalOpen('add')}
                        className="flex-1 bg-white text-indigo-900 py-2 rounded-xl font-bold text-xs flex items-center justify-center gap-1 hover:bg-indigo-50 transition-colors"
                      >
                          <Plus size={14} /> Adicionar
                      </button>
                      <button 
                        onClick={() => setModalOpen('withdraw')}
                        className="flex-1 bg-indigo-800 text-indigo-200 py-2 rounded-xl font-bold text-xs flex items-center justify-center gap-1 hover:bg-indigo-700 transition-colors border border-indigo-700"
                      >
                          <ArrowUpRight size={14} /> Retirar
                      </button>
                  </div>
              </div>
          </motion.div>

          {/* Cards Decorativos / Info */}
          <div className="md:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="bg-surface border border-slate-700 p-6 rounded-3xl flex items-center gap-4">
                  <div className="p-4 bg-emerald-500/10 rounded-2xl text-emerald-400">
                      <CreditCard size={28} />
                  </div>
                  <div>
                      <h4 className="font-bold text-slate-200">Pagamentos Seguros</h4>
                      <p className="text-xs text-slate-500">Suas transações são protegidas por criptografia de ponta a ponta.</p>
                  </div>
              </div>
              <div className="bg-surface border border-slate-700 p-6 rounded-3xl flex items-center gap-4">
                   <div className="p-4 bg-purple-500/10 rounded-2xl text-purple-400">
                      <Coins size={28} />
                  </div>
                  <div>
                      <h4 className="font-bold text-slate-200">Cashback Capitalyx</h4>
                      <p className="text-xs text-slate-500">Ganhe 1% de volta em todas as compras acima de R$ 100.</p>
                  </div>
              </div>
          </div>
      </div>

      {/* Grid da Loja */}
      <div>
          <h3 className="text-lg font-bold text-white mb-6 flex items-center gap-2">
              <Zap className="text-yellow-400" size={20} />
              Destaques da Semana
          </h3>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {STORE_ITEMS.map((item, idx) => {
                  // Verificação segura de array
                  const isOwned = item.id === 6 && Array.isArray(user.badges) && user.badges.includes('supporter');
                  
                  return (
                  <motion.div 
                    key={item.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: idx * 0.1 }}
                    className="bg-surface border border-slate-700 rounded-3xl p-6 hover:border-indigo-500/50 transition-all group relative overflow-hidden"
                  >
                      <div className={`w-12 h-12 rounded-2xl ${item.color} flex items-center justify-center text-white mb-4 shadow-lg`}>
                          <item.icon size={24} />
                      </div>
                      
                      <h4 className="text-lg font-bold text-white mb-1 group-hover:text-indigo-400 transition-colors">{item.name}</h4>
                      <p className="text-sm text-slate-400 mb-6 h-10">{item.desc}</p>
                      
                      <div className="flex items-center justify-between pt-4 border-t border-slate-700">
                          <span className="font-bold text-xl text-slate-200">{formatCurrency(item.price)}</span>
                          <button 
                            onClick={() => handlePurchase(item)}
                            disabled={loading || isOwned}
                            className={`px-4 py-2 rounded-xl text-sm font-bold transition-all disabled:opacity-50 disabled:cursor-not-allowed ${
                                isOwned 
                                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' 
                                : 'bg-slate-800 hover:bg-white hover:text-indigo-900 text-white'
                            }`}
                          >
                             {isOwned ? 'Adquirido' : 'Comprar'}
                          </button>
                      </div>
                  </motion.div>
              )})}
          </div>
      </div>

      {/* Modais de Transação */}
      <AnimatePresence>
        {modalOpen && (
             <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
             >
                <motion.div 
                    initial={{ scale: 0.9 }}
                    animate={{ scale: 1 }}
                    exit={{ scale: 0.9 }}
                    className="bg-surface w-full max-w-sm rounded-3xl border border-slate-700 shadow-2xl p-6"
                >
                    <h3 className="text-xl font-bold text-white mb-4">
                        {modalOpen === 'add' ? 'Adicionar Saldo' : 'Retirar Saldo'}
                    </h3>
                    
                    <div className="space-y-4">
                        <div>
                            <label className="text-xs font-bold text-slate-400 uppercase ml-1">Valor (R$)</label>
                            <input 
                                type="number" 
                                autoFocus
                                value={amountInput}
                                onChange={(e) => setAmountInput(e.target.value)}
                                className="w-full bg-slate-900 border border-slate-700 rounded-xl p-3 text-white focus:outline-none focus:border-indigo-500 text-lg font-bold"
                                placeholder="0,00"
                            />
                        </div>
                        
                        <div className="flex gap-3 pt-2">
                            <button 
                                onClick={() => setModalOpen(null)}
                                className="flex-1 py-3 rounded-xl border border-slate-600 text-slate-300 hover:bg-slate-800 transition-colors font-bold text-sm"
                            >
                                Cancelar
                            </button>
                            <button 
                                onClick={handleTransaction}
                                disabled={loading}
                                className={`flex-1 py-3 rounded-xl text-white font-bold text-sm flex justify-center items-center gap-2 ${modalOpen === 'add' ? 'bg-indigo-600 hover:bg-indigo-500' : 'bg-emerald-600 hover:bg-emerald-500'}`}
                            >
                                {loading ? <Loader2 className="animate-spin" size={16} /> : <Check size={16} />}
                                Confirmar
                            </button>
                        </div>
                    </div>
                </motion.div>
             </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
};

export default Store;
