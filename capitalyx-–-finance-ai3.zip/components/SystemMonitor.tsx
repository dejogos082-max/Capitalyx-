
import React, { useEffect, useRef } from 'react';
import { subscribeToIntegrityConfig, updateIntegrityState, auth } from '../services/firebase';
import { runAIIntegrityCheck } from '../services/aiMonitor';
import { IntegrityState, UserProfile } from '../types';

/**
 * Monitor de Sistema em Segundo Plano.
 * Restrito para executar escritas somente se o usuário tiver privilégios administrativos.
 */
interface SystemMonitorProps {
    user: UserProfile;
}

const SystemMonitor: React.FC<SystemMonitorProps> = ({ user }) => {
    const configRef = useRef<IntegrityState | null>(null);
    const intervalRef = useRef<any>(null);

    // 1. Inscrição no estado de configuração
    useEffect(() => {
        const unsub = subscribeToIntegrityConfig((cfg) => {
            const prevConfig = configRef.current;
            configRef.current = cfg;

            // Trigger: Check Forçado (Somente Admins podem disparar, mas o monitor reage)
            if (prevConfig && cfg.forceCheckTrigger > prevConfig.forceCheckTrigger) {
                executeCheck("Disparado por Administrador ou Auto-Correção IA");
            }

            // Trigger: Novo Usuário Registrado (Reseta Pausa)
            if (prevConfig && cfg.newUserTrigger > prevConfig.newUserTrigger) {
                handleNewUserEvent();
            }

            // Auto-início se parado por muito tempo (> 24h)
            if (cfg.status === 'paused' || cfg.status === 'error' || cfg.status === 'idle') {
                 const timeSinceLast = Date.now() - (cfg.lastCheckTime || 0);
                 if (timeSinceLast > 24 * 60 * 60 * 1000) {
                     console.log("[SystemMonitor] Reiniciando serviço de monitoramento automático...");
                     executeCheck("Auto-Start (Ciclo de 24h)");
                 }
            }
        });
        return () => unsub();
    }, [user.uid, user.isAdministrator]);

    // 2. Setup de Intervalo (Simulação de Worker 24h)
    useEffect(() => {
        intervalRef.current = setInterval(() => {
            checkSchedule();
        }, 24 * 60 * 60 * 1000);

        return () => clearInterval(intervalRef.current);
    }, []);

    const handleNewUserEvent = async () => {
        // Somente administradores ou processos autenticados com permissão de escrita global podem executar isso
        if (!user.isAdministrator) return;

        console.log("[SystemMonitor] Novo usuário detectado. Iniciando varredura inicial...");
        
        try {
            await updateIntegrityState({
                checkCount: 0,
                isPaused: false,
                status: 'running'
            });
            executeCheck("Registro de Novo Usuário");
        } catch (e) {
            console.warn("[SystemMonitor] Falha ao atualizar estado de integridade (Permissão negada).");
        }
    };

    const checkSchedule = async () => {
        if (!configRef.current || !user.isAdministrator) return;
        executeCheck(`Check Diário (Ciclo 24h)`);
    };

    const executeCheck = async (reason: string) => {
        // CRITICAL FIX: Somente tenta gravar no banco global se for administrador
        if (!configRef.current || !user.isAdministrator) {
            if (reason.includes("Disparado")) {
                console.log("[SystemMonitor] Ignorando check de integridade: Usuário sem privilégios administrativos.");
            }
            return;
        }

        try {
            await updateIntegrityState({ 
                status: 'running',
                lastCheckTime: Date.now()
            });

            console.log(`[SystemMonitor] Executando Check: ${reason}`);
            
            // O check de IA em si pode falhar se o provider estiver fora, tratamos internamente
            await runAIIntegrityCheck();

            await updateIntegrityState({
                checkCount: (configRef.current.checkCount || 0) + 1,
                status: 'idle',
                isPaused: false
            });

        } catch (e: any) {
            if (e.message && e.message.includes("PERMISSION_DENIED")) {
                console.warn("[SystemMonitor] Permissão negada para gravar em system_settings.");
            } else {
                console.error("[SystemMonitor] Erro durante o check:", e);
                await updateIntegrityState({ status: 'error' });
            }
        }
    };

    return null; // Componente invisível
};

export default SystemMonitor;
