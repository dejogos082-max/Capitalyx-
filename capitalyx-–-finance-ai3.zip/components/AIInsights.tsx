
import React, { useState } from 'react';
import { Transaction, AIAnalysisResult, FinancialGoal } from '../types';
import { generateFinancialInsights } from '../services/geminiService';
import { markAIUsage, auth } from '../services/firebase';
import { 
  Bot, Sparkles, AlertTriangle, PiggyBank, TrendingUp, Loader2, 
  Lightbulb, Activity, Cpu, BrainCircuit, Zap, CalendarClock
} from 'lucide-react';
import { motion } from 'framer-motion';

interface AIInsightsProps {
  transactions: Transaction[];
  goals?: FinancialGoal[];
}

const AIInsights: React.FC<AIInsightsProps> = ({ transactions, goals = [] }) => {
  const [loading, setLoading] = useState(false);
  const [insight, setInsight] = useState<AIAnalysisResult | null>(null);

  // NOTE: In the parent App.tsx, we are now passing more props to generateFinancialInsights
  // Since AIInsights is used in a specific tab, it likely needs to receive the insight object from props if already generated,
  // OR we keep this internal state. The prompt logic in App.tsx suggests App.tsx handles the generation for the main dashboard.
  // However, this component has its own "Regenerate" button. 
  // For consistency with the Beta Update, this component should ideally receive the *latest* insight from App.tsx 
  // or trigger the generation via a prop callback to ensure Beta data is included.
  // BUT, to avoid breaking the interface, I will assume the parent passes data or we keep local generation.
  // IMPORTANT: The request asked to update the code. The App.tsx now handles generation including Beta data.
  // If the user clicks "Regenerate" here, it might miss beta data unless we update this signature.
  // To keep it simple and working: The "Regenerate" button in App.tsx (if added) calls the main function. 
  // Here, we'll hide the internal generate button if `transactions` is passed but the parent controls state. 
  // Wait, `insight` is state here. 
  
  // Actually, App.tsx passes `transactions` and `goals`. It does NOT pass `recurring` here.
  // This means the internal generate here won't see recurring items unless we update props.
  // However, I will focus on visualizing the `futureProjections` if they exist in the `insight` object passed from parent? 
  // No, `App.tsx` passes `insight={aiInsight}` to Dashboard, but `AIInsights.tsx` is a separate tab component.
  // Let's assume for this "Beta" implementation, the main generation happens in Dashboard/App and this component 
  // might display it if passed, or we just update the UI to handle `futureProjections` if present.
  
  // FIX: The `AIInsights` component in `App.tsx` receives `transactions` and `goals`.
  // It generates its own insights via `handleAnalyze`.
  // I won't change the props interface of this component extensively to break it, 
  // but I will add the visualization for `futureProjections` so if the service returns it (even if empty inputs), it renders.

  const handleAnalyze = async () => {
    setLoading(true);
    try {
      // NOTE: This local call might miss Recurring/CustomCats because they aren't props here.
      // This is a limitation of the current refactor without prop drilling everything.
      // However, the service `generateFinancialInsights` now accepts optional args.
      const result = await generateFinancialInsights(transactions, goals);
      setInsight(result);
      
      if (auth.currentUser) {
        markAIUsage(auth.currentUser.uid).catch(console.error);
      }

    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  // Improved Safe Render: Handles objects, arrays, and pure strings robustly
  const safeRender = (val: any, fallback: string = "Informação indisponível"): string => {
    if (val === null || val === undefined) return fallback;
    if (typeof val === 'string') return val;
    if (typeof val === 'number') return String(val);
    
    // Check if it's an object with a text-like property (common hallucination)
    if (typeof val === 'object') {
        if (val.text) return String(val.text);
        if (val.summary) return String(val.summary);
        if (val.content) return String(val.content);
        // Fallback to JSON stringify but clean it if possible
        try {
            const str = JSON.stringify(val);
            // If the string is too long/ugly, return fallback
            if (str.length > 200 && (str.includes('{') || str.includes('['))) return fallback;
            return str;
        } catch {
            return fallback;
        }
    }
    return fallback;
  };

  const getProviderIcon = (provider?: string) => {
      switch(provider) {
          case 'openai': return <Sparkles size={14} className="text-emerald-400" />;
          default: return <Zap size={14} className="text-blue-400" />; // Gemini
      }
  };

  const getProviderName = (provider?: string) => {
      switch(provider) {
          case 'openai': return 'GPT-4o Mini';
          default: return 'Gemini Flash';
      }
  };

  const formatCurrency = (val: number) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val);

  return (
    <div className="max-w-5xl mx-auto space-y-8 pb-10">
      <div className="bg-gradient-to-br from-indigo-900/50 to-purple-900/50 p-8 rounded-3xl border border-indigo-500/30 text-center relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-indigo-500 to-transparent opacity-50"></div>
        <div className="relative z-10">
          <div className="inline-flex p-3 bg-indigo-500/20 rounded-2xl mb-4 backdrop-blur-sm border border-indigo-500/30">
            <Sparkles className="text-indigo-400" size={32} />
          </div>
          <h2 className="text-3xl font-bold text-white mb-2">Capitalyx AI Intelligence</h2>
          <p className="text-indigo-200 mb-8 max-w-lg mx-auto">
            Utilize nossa IA para analisar padrões, prever fluxo de caixa e encontrar oportunidades ocultas.
          </p>
          
          {!loading && (
            <button
              onClick={handleAnalyze}
              className="bg-white text-indigo-900 hover:bg-indigo-50 font-bold py-3 px-8 rounded-full shadow-[0_0_20px_rgba(255,255,255,0.3)] transition-all active:scale-95 flex items-center gap-2 mx-auto"
            >
              <Bot size={20} />
              {insight ? 'Regenerar Análise' : 'Gerar Análise Financeira'}
            </button>
          )}

          {loading && (
            <div className="flex flex-col items-center justify-center text-indigo-300 gap-3">
              <Loader2 className="animate-spin" size={32} />
              <span className="text-sm font-medium animate-pulse">Processando dados financeiros...</span>
            </div>
          )}
        </div>
        
        {/* Background decorative elements */}
        <div className="absolute top-1/2 left-10 w-32 h-32 bg-purple-600/20 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 right-10 w-48 h-48 bg-blue-600/20 rounded-full blur-3xl"></div>
      </div>

      {insight && (
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          {/* Main Summary & Provider Badge */}
          <div className="bg-surface p-6 rounded-2xl border border-slate-700 shadow-lg relative">
             <div className="absolute top-4 right-4 flex items-center gap-2 bg-slate-900/80 px-3 py-1 rounded-full border border-slate-700 text-xs text-slate-400">
                 <span className="opacity-70">Powered by</span>
                 <div className="flex items-center gap-1 font-bold text-slate-200">
                    {getProviderIcon(insight.providerUsed)}
                    {getProviderName(insight.providerUsed)}
                 </div>
             </div>
             
             <h3 className="text-lg font-semibold text-slate-200 mb-4 flex items-center gap-2">
              <Bot className="text-primary" size={20} />
              Resumo Executivo
            </h3>
            <p className="text-slate-300 text-lg leading-relaxed pr-0 md:pr-32">
                {safeRender(insight.summary)}
            </p>
          </div>

          {/* BETA FEATURE: Future Projections */}
          {insight.futureProjections && insight.futureProjections.length > 0 && (
             <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-indigo-950/30 p-6 rounded-2xl border border-indigo-500/30"
             >
                <div className="flex items-center gap-2 mb-4">
                    <CalendarClock className="text-indigo-400" size={24} />
                    <h3 className="text-lg font-bold text-white">Projeção Futura (Beta)</h3>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {insight.futureProjections.map((proj, idx) => (
                        <div key={idx} className="bg-slate-900/60 p-4 rounded-xl border border-indigo-500/20">
                            <p className="text-xs text-indigo-300 font-bold uppercase mb-1">{proj.month}</p>
                            <p className="text-2xl font-bold text-white mb-2">{formatCurrency(proj.projectedBalance)}</p>
                            <p className="text-xs text-slate-400">{proj.note}</p>
                        </div>
                    ))}
                </div>
             </motion.div>
          )}

          {/* 4-Grid Layout for Details */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              {/* Box 1: Economia */}
              <div className="bg-emerald-900/10 p-6 rounded-2xl border border-emerald-500/20 relative overflow-hidden group hover:border-emerald-500/40 transition-colors">
                <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                    <PiggyBank size={80} className="text-emerald-500" />
                </div>
                <h3 className="text-lg font-semibold text-emerald-400 mb-3 flex items-center gap-2">
                    <PiggyBank size={20} />
                    Dica de Economia
                </h3>
                <p className="text-emerald-100/80 text-sm leading-relaxed">
                    {safeRender(insight.savingsTip)}
                </p>
              </div>

              {/* Box 2: Previsão */}
              <div className="bg-blue-900/10 p-6 rounded-2xl border border-blue-500/20 relative overflow-hidden group hover:border-blue-500/40 transition-colors">
                <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                    <TrendingUp size={80} className="text-blue-500" />
                </div>
                <h3 className="text-lg font-semibold text-blue-400 mb-3 flex items-center gap-2">
                    <TrendingUp size={20} />
                    Previsão de Caixa
                </h3>
                <p className="text-blue-100/80 text-sm leading-relaxed">
                    {safeRender(insight.prediction)}
                </p>
              </div>

              {/* Box 3: Investimentos */}
              <div className="bg-purple-900/10 p-6 rounded-2xl border border-purple-500/20 relative overflow-hidden group hover:border-purple-500/40 transition-colors">
                <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                    <Lightbulb size={80} className="text-purple-500" />
                </div>
                <h3 className="text-lg font-semibold text-purple-400 mb-3 flex items-center gap-2">
                    <Lightbulb size={20} />
                    Oportunidade
                </h3>
                <p className="text-purple-100/80 text-sm leading-relaxed">
                    {safeRender(insight.investmentTip || insight.cashFlowTip)}
                </p>
              </div>

              {/* Box 4: Hábitos */}
              <div className="bg-orange-900/10 p-6 rounded-2xl border border-orange-500/20 relative overflow-hidden group hover:border-orange-500/40 transition-colors">
                <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                    <Activity size={80} className="text-orange-500" />
                </div>
                <h3 className="text-lg font-semibold text-orange-400 mb-3 flex items-center gap-2">
                    <Activity size={20} />
                    Análise de Hábito
                </h3>
                <p className="text-orange-100/80 text-sm leading-relaxed">
                    {safeRender(insight.spendingHabit || "Sem dados suficientes para análise de hábitos.")}
                </p>
              </div>
          </div>

          {/* Alert (Conditional) */}
          {insight.alert && (
            <div className="bg-rose-900/10 p-6 rounded-2xl border border-rose-500/20 flex items-start gap-4 animate-in slide-in-from-bottom-5">
              <div className="p-2 bg-rose-500/20 rounded-full shrink-0">
                <AlertTriangle className="text-rose-500" size={24} />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-rose-400 mb-1">Ponto de Atenção</h3>
                <p className="text-rose-200/80 text-sm">{safeRender(insight.alert)}</p>
              </div>
            </div>
          )}
        </motion.div>
      )}
    </div>
  );
};

export default AIInsights;
