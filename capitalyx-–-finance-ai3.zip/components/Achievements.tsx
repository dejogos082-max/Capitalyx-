
import React, { useState } from 'react';
import { Achievement } from '../types';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Trophy, TrendingUp, TrendingDown, Bot, Database, Lock, Medal, 
  ArrowLeft, TestTube2, FastForward, Smartphone, Monitor, CalendarCheck, Briefcase, Crown,
  Target, Award, BrainCircuit, User as UserIcon
} from 'lucide-react';

interface AchievementsProps {
  achievements: Achievement[];
}

const getIcon = (ach: Achievement, isUnlocked: boolean) => {
  const className = isUnlocked ? "text-white" : "text-slate-500";
  const size = 32;

  if (ach.iconUrl) {
      return (
          <img 
            src={ach.iconUrl} 
            alt={ach.title} 
            className={`w-8 h-8 object-contain ${!isUnlocked ? 'grayscale opacity-50' : ''}`} 
          />
      );
  }

  // Mapeamento de ícones baseado no iconName da conquista
  switch (ach.iconName) {
    case 'FirstIncome': return <TrendingUp size={size} className={isUnlocked ? "text-emerald-400" : className} />;
    case 'FirstExpense': return <TrendingDown size={size} className={isUnlocked ? "text-rose-400" : className} />;
    case 'FirstAI': return <Bot size={size} className={isUnlocked ? "text-indigo-400" : className} />;
    case 'DataMaster': return <Database size={size} className={isUnlocked ? "text-blue-400" : className} />;
    case 'Saver': return <Medal size={size} className={isUnlocked ? "text-yellow-400" : className} />;
    case 'BetaTester': return <TestTube2 size={size} className={isUnlocked ? "text-fuchsia-400" : className} />;
    case 'FutureVision': return <FastForward size={size} className={isUnlocked ? "text-cyan-400" : className} />;
    case 'MobileUser': return <Smartphone size={size} className={isUnlocked ? "text-orange-400" : className} />;
    case 'PCUser': return <Monitor size={size} className={isUnlocked ? "text-blue-500" : className} />;
    case 'TimeTraveler': return <CalendarCheck size={size} className={isUnlocked ? "text-teal-400" : className} />;
    case 'CareerFocus': return <Briefcase size={size} className={isUnlocked ? "text-purple-400" : className} />;
    case 'FinanceMaster': return <Crown size={size} className={isUnlocked ? "text-amber-400" : className} />;
    case 'Medal': return <Medal size={size} className={isUnlocked ? "text-yellow-400" : className} />;
    case 'Target': return <Target size={size} className={isUnlocked ? "text-indigo-400" : className} />;
    case 'Award': return <Award size={size} className={isUnlocked ? "text-emerald-400" : className} />;
    case 'BrainCircuit': return <BrainCircuit size={size} className={isUnlocked ? "text-purple-400" : className} />;
    case 'User': return <UserIcon size={size} className={className} />;
    case 'Crown': return <Crown size={size} className={isUnlocked ? "text-amber-400" : className} />;
    default: return <Trophy size={size} className={className} />;
  }
};

const Achievements: React.FC<AchievementsProps> = ({ achievements }) => {
  const [showFullGallery, setShowFullGallery] = useState(false);
  const unlockedCount = achievements.filter(a => a.isUnlocked).length;
  const totalProgress = achievements.length > 0 ? (unlockedCount / achievements.length) * 100 : 0;

  const unlockedList = achievements.filter(a => a.isUnlocked);
  const lockedList = achievements.filter(a => !a.isUnlocked);

  if (showFullGallery) {
      return (
        <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="space-y-8 pb-20"
        >
            <div className="flex items-center gap-4 mb-6">
                <button 
                    onClick={() => setShowFullGallery(false)}
                    className="p-2 bg-slate-800 rounded-full hover:bg-slate-700 transition-colors border border-slate-700"
                >
                    <ArrowLeft size={24} className="text-slate-200" />
                </button>
                <div>
                    <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                        <Trophy className="text-yellow-500" />
                        Galeria de Conquistas
                    </h2>
                    <p className="text-sm text-slate-400">Sua jornada financeira gamificada</p>
                </div>
            </div>

            <div>
                <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2 px-2">
                    <Medal className="text-emerald-500" size={20} />
                    Desbloqueadas ({unlockedList.length})
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {unlockedList.length > 0 ? unlockedList.map(ach => (
                        <div key={ach.id} className="bg-gradient-to-br from-slate-800 to-slate-900 border border-emerald-500/30 p-4 rounded-2xl flex items-start gap-4 shadow-lg shadow-emerald-900/10">
                            <div className="p-3 bg-slate-800 rounded-xl border border-slate-700 flex-shrink-0">
                                {getIcon(ach, true)}
                            </div>
                            <div>
                                <h4 className="font-bold text-white">{ach.title}</h4>
                                <p className="text-xs text-slate-400 mt-1">{ach.description}</p>
                            </div>
                        </div>
                    )) : (
                        <div className="col-span-full py-8 text-center text-slate-500 italic">
                            Você ainda não desbloqueou conquistas. Comece a usar o app!
                        </div>
                    )}
                </div>
            </div>

            <div className="pt-8 border-t border-slate-800">
                <h3 className="text-lg font-bold text-slate-400 mb-4 flex items-center gap-2 px-2">
                    <Lock className="text-slate-600" size={20} />
                    Conquistas Futuras ({lockedList.length})
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 opacity-90">
                    {lockedList.map(ach => (
                        <div key={ach.id} className="bg-slate-900 border border-slate-800 p-4 rounded-2xl flex flex-col gap-4 group">
                            <div className="flex items-start gap-4">
                                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 group-hover:border-slate-600 transition-colors flex-shrink-0 grayscale">
                                    {getIcon(ach, false)}
                                </div>
                                <div>
                                    <h4 className="font-bold text-slate-300 group-hover:text-white transition-colors">{ach.title}</h4>
                                    <p className="text-xs text-slate-400 mt-1">{ach.description}</p>
                                </div>
                            </div>
                            <div className="space-y-1.5">
                                <div className="flex justify-between text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                                    <span>Progresso</span>
                                    <span>{Math.round(ach.progress || 0)}%</span>
                                </div>
                                <div className="h-1.5 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                                    <motion.div 
                                        initial={{ width: 0 }}
                                        animate={{ width: `${ach.progress || 0}%` }}
                                        className="h-full bg-slate-700"
                                    />
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </motion.div>
      );
  }

  return (
    <div className="space-y-8">
      <div 
        onClick={() => setShowFullGallery(true)}
        className="bg-surface border border-slate-700 p-6 rounded-2xl shadow-xl relative overflow-hidden cursor-pointer group hover:border-primary/50 transition-colors"
      >
        <div className="absolute top-0 left-0 w-full h-1 bg-slate-700">
           <motion.div 
             initial={{ width: 0 }}
             animate={{ width: `${totalProgress}%` }}
             transition={{ duration: 1, ease: "easeOut" }}
             className="h-full bg-gradient-to-r from-primary to-secondary"
           />
        </div>
        
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 mt-2">
          <div>
             <h2 className="text-2xl font-bold text-white flex items-center gap-2 group-hover:text-primary transition-colors">
                <Trophy className="text-yellow-500" />
                Galeria de Conquistas
             </h2>
             <p className="text-slate-400 group-hover:text-slate-300">Toque para ver todas as missões</p>
          </div>
          <div className="text-right">
             <span className="text-4xl font-bold text-white">{unlockedCount}</span>
             <span className="text-slate-500 text-xl">/{achievements.length}</span>
          </div>
        </div>
        <div className="absolute bottom-2 right-4 text-[10px] text-slate-500 font-medium uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-opacity">
            Ver Detalhes
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {achievements.slice(0, 3).map((ach) => (
          <motion.div
            key={ach.id}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className={`relative p-6 rounded-2xl border transition-all duration-300 overflow-hidden ${
              ach.isUnlocked 
                ? 'bg-surface border-slate-600 shadow-lg shadow-primary/10' 
                : 'bg-slate-900/50 border-slate-800 opacity-80'
            }`}
          >
            <div className="flex items-start justify-between mb-4 relative z-10">
               <div className={`p-4 rounded-xl ${
                 ach.isUnlocked 
                   ? 'bg-gradient-to-br from-slate-700 to-slate-800 shadow-inner' 
                   : 'bg-slate-800'
               }`}>
                  {getIcon(ach, ach.isUnlocked)}
               </div>
               {ach.isUnlocked ? (
                  <motion.div 
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="bg-yellow-500/20 text-yellow-400 text-xs px-2 py-1 rounded-full border border-yellow-500/30"
                  >
                    Conquistado
                  </motion.div>
               ) : (
                 <Lock className="text-slate-600" size={20} />
               )}
            </div>

            <div className="relative z-10 mb-4">
              <h3 className={`text-lg font-bold mb-1 ${ach.isUnlocked ? 'text-white' : 'text-slate-500'}`}>
                {ach.title}
              </h3>
              <p className="text-sm text-slate-400 leading-relaxed line-clamp-2">
                {ach.description}
              </p>
            </div>

            {!ach.isUnlocked && (
                <div className="h-1 bg-slate-800 rounded-full overflow-hidden">
                    <div 
                        className="h-full bg-slate-600"
                        style={{ width: `${ach.progress || 0}%` }}
                    />
                </div>
            )}
          </motion.div>
        ))}
        {achievements.length > 3 && (
            <div 
                onClick={() => setShowFullGallery(true)}
                className="flex items-center justify-center p-6 rounded-2xl border border-slate-800 border-dashed bg-slate-900/30 text-slate-500 hover:text-white hover:bg-slate-800 hover:border-slate-600 cursor-pointer transition-all"
            >
                <p className="text-sm font-bold">+ {achievements.length - 3} Outras</p>
            </div>
        )}
      </div>
    </div>
  );
};

export default Achievements;
