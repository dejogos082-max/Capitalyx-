
import React, { useEffect, useState } from 'react';
import { Transaction, TransactionType, AIAnalysisResult, FinancialGoal, FinancialScoreResult, RecurringTransaction } from '../types';
import { generateFinancialScore } from '../services/geminiService';
import { 
  ArrowUpCircle, ArrowDownCircle, Wallet, TrendingUp, Sparkles, 
  ChevronRight, ChevronLeft, Target, Plus, LayoutDashboard, 
  PieChart, Award, User, Settings, Shield, 
  WalletCards, Banknote, ArrowLeft, RotateCw, Gauge, Zap
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, AreaChart, Area, CartesianGrid } from 'recharts';
import ExtendedAnalytics from './ExtendedAnalytics';
import DetailedView from './DetailedView';
// NEW IMPORT
import { FutureSimulator, InteractiveCalendar } from './BetaWidgets';

interface DashboardProps {
  transactions: Transaction[];
  aiInsight: AIAnalysisResult | null;
  onGenerateAI: () => void;
  goals?: FinancialGoal[];
  setActiveTab?: (tab: string) => void;
  onOpenTransactionForm?: () => void;
  // NEW PROPS
  isBetaMode?: boolean;
  recurringTransactions?: RecurringTransaction[];
  onAddTransactionOnDate?: (date: string) => void;
  onUpdateStats?: (stats: any) => void; // New prop for gamification
}

const formatCurrency = (value: number) => {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL'
  }).format(value);
};

const Dashboard: React.FC<DashboardProps> = ({ 
  transactions, aiInsight, onGenerateAI, goals = [], 
  setActiveTab, onOpenTransactionForm,
  isBetaMode = false, recurringTransactions = [], onAddTransactionOnDate, onUpdateStats
}) => {
  const [currentView, setCurrentView] = useState<'default' | 'extended' | 'menu_grid' | 'detail_balance' | 'detail_income' | 'detail_expense'>('default');
  const [scoreData, setScoreData] = useState<FinancialScoreResult | null>(null);
  const [loadingScore, setLoadingScore] = useState(false);
  
  // Geração Automática de IA
  useEffect(() => {
    if (!aiInsight && transactions.length >= 3) {
      const timer = setTimeout(() => {
        onGenerateAI();
      }, 1000); 
      return () => clearTimeout(timer);
    }
  }, [transactions.length, aiInsight, onGenerateAI]);

  // Carregar Score se não existir e houver dados
  useEffect(() => {
      if (!scoreData && transactions.length > 2) {
          handleCalculateScore();
      }
  }, [transactions.length]);

  const handleCalculateScore = async () => {
      setLoadingScore(true);
      try {
          const result = await generateFinancialScore(transactions);
          setScoreData(result);
      } catch (e) {
          console.error("Score Error", e);
      } finally {
          setLoadingScore(false);
      }
  };

  const stats = React.useMemo(() => {
    return transactions.reduce(
      (acc, t) => {
        if (t.type === TransactionType.INCOME) {
          acc.income += t.amount;
        } else {
          acc.expense += t.amount;
        }
        acc.balance = acc.income - acc.expense;
        return acc;
      },
      { income: 0, expense: 0, balance: 0 }
    );
  }, [transactions]);

  const chartData = React.useMemo(() => {
    const dataMap: Record<string, { name: string; income: number; expense: number }> = {};
    const now = new Date();
    for(let i = 6; i >= 0; i--) {
        const d = new Date();
        d.setDate(now.getDate() - i);
        const key = d.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
        dataMap[key] = { name: key, income: 0, expense: 0 };
    }

    transactions.forEach(t => {
       const date = new Date(t.date);
       const key = date.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
       if (dataMap[key]) {
           if (t.type === TransactionType.INCOME) dataMap[key].income += t.amount;
           else dataMap[key].expense += t.amount;
       }
    });

    return Object.values(dataMap);
  }, [transactions]);

  // Swipe Logic
  const handleDragEnd = (event: any, info: any) => {
    const threshold = 100;
    
    // De Default para Menu (Swipe para a esquerda) ou Extended (Swipe para a direita)
    if (currentView === 'default') {
        if (info.offset.x < -threshold) {
            setCurrentView('menu_grid');
        } else if (info.offset.x > threshold) {
            setCurrentView('extended');
        }
    } 
    // Voltando para Default
    else if (currentView === 'menu_grid' && info.offset.x > threshold) {
        setCurrentView('default');
    } else if (currentView === 'extended' && info.offset.x < -threshold) {
        setCurrentView('default');
    }
  };

  const variants = {
    enter: (direction: number) => ({
      x: direction > 0 ? -300 : 300,
      opacity: 0,
      scale: 0.95
    }),
    center: {
      zIndex: 1,
      x: 0,
      opacity: 1,
      scale: 1
    },
    exit: (direction: number) => ({
      zIndex: 0,
      x: direction < 0 ? 300 : -300,
      opacity: 0,
      scale: 0.95
    })
  };

  const getDirection = () => {
      if (currentView === 'extended') return -1;
      if (currentView === 'menu_grid') return 1;
      return 0;
  };

  const direction = getDirection();

  // Navigation Items for Grid
  const menuItems = [
    { id: 'dashboard', label: 'Início', icon: LayoutDashboard, color: 'text-blue-400' },
    { id: 'transactions', label: 'Registros', icon: WalletCards, color: 'text-emerald-400' },
    { id: 'goals', label: 'Metas', icon: Target, color: 'text-indigo-400' },
    { id: 'analytics', label: 'Insights AI', icon: PieChart, color: 'text-purple-400' },
    { id: 'achievements', label: 'Conquistas', icon: Award, color: 'text-yellow-400' },
    { id: 'profile', label: 'Perfil', icon: User, color: 'text-slate-300' },
    { id: 'settings', label: 'Ajustes', icon: Settings, color: 'text-slate-500' },
  ];

  // Quick Access Views
  if (currentView === 'detail_balance') {
      return <DetailedView type="balance" transactions={transactions} onBack={() => setCurrentView('default')} />;
  }
  if (currentView === 'detail_income') {
      return <DetailedView type="income" transactions={transactions} onBack={() => setCurrentView('default')} />;
  }
  if (currentView === 'detail_expense') {
      return <DetailedView type="expense" transactions={transactions} onBack={() => setCurrentView('default')} />;
  }

  const safeCashFlowTip = aiInsight?.cashFlowTip && typeof aiInsight.cashFlowTip === 'string' 
    ? aiInsight.cashFlowTip 
    : (aiInsight?.cashFlowTip ? "Dica detalhada disponível na aba Insights." : null);

  const getScoreColor = (score: number) => {
      if (score >= 800) return 'text-emerald-400';
      if (score >= 600) return 'text-blue-400';
      if (score >= 400) return 'text-yellow-400';
      return 'text-rose-400';
  };

  const getScoreGradient = (score: number) => {
      if (score >= 800) return 'from-emerald-500 to-teal-400';
      if (score >= 600) return 'from-blue-500 to-indigo-400';
      if (score >= 400) return 'from-yellow-500 to-orange-400';
      return 'from-rose-500 to-red-400';
  };

  // SVG Maths: r=45, viewBox 0 0 100 100
  // C = 2 * PI * 45 ≈ 283
  const scoreCircumference = 283; 

  return (
    <div className="relative w-full min-h-[80vh] flex flex-col overflow-x-hidden">
      <AnimatePresence initial={false} custom={direction} mode='popLayout'>
        
        {currentView === 'default' && (
            <motion.div
                key="default"
                custom={direction}
                variants={variants}
                initial="enter"
                animate="center"
                exit="exit"
                transition={{ type: "spring", stiffness: 300, damping: 30 }}
                className="space-y-6 w-full pb-20"
                drag="x"
                dragConstraints={{ left: 0, right: 0 }}
                dragElastic={0.05}
                onDragEnd={handleDragEnd}
                style={{ touchAction: "pan-y" }}
            >
                {/* --- BETA WIDGETS SECTION --- */}
                {isBetaMode && (
                    <motion.div 
                        initial={{ opacity: 0, height: 0 }} 
                        animate={{ opacity: 1, height: 'auto' }}
                        className="space-y-6 mb-6"
                    >
                        <FutureSimulator 
                            currentBalance={stats.balance} 
                            recurringTransactions={recurringTransactions} 
                            onUpdateStats={onUpdateStats} // Pass handler
                        />
                        <InteractiveCalendar 
                            recurringTransactions={recurringTransactions}
                            onAddTransaction={onAddTransactionOnDate} // Passing the handler
                            onUpdateStats={onUpdateStats} // Pass handler
                        />
                    </motion.div>
                )}

                {/* ATALHOS RÁPIDOS (WIDGETS) */}
                <div className="grid grid-cols-2 gap-4">
                    <motion.button 
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        onClick={() => setActiveTab?.('goals')}
                        className="bg-indigo-600/20 border border-indigo-500/30 p-4 rounded-2xl flex flex-col items-center justify-center gap-2 group transition-all"
                    >
                        <div className="bg-indigo-500/20 p-2 rounded-xl text-indigo-400 group-hover:bg-indigo-500 group-hover:text-white transition-colors">
                            <Target size={24} />
                        </div>
                        <span className="text-sm font-bold text-indigo-100">Ver Metas</span>
                    </motion.button>
                    
                    <motion.button 
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        onClick={onOpenTransactionForm}
                        className="bg-emerald-600/20 border border-emerald-500/30 p-4 rounded-2xl flex flex-col items-center justify-center gap-2 group transition-all"
                    >
                        <div className="bg-emerald-500/20 p-2 rounded-xl text-emerald-400 group-hover:bg-emerald-500 group-hover:text-white transition-colors">
                            <Plus size={24} />
                        </div>
                        <span className="text-sm font-bold text-emerald-100">Add Registro</span>
                    </motion.button>
                </div>

                {/* ... Rest of Dashboard remains unchanged ... */}
                 {/* CARDS PRINCIPAIS */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <motion.button 
                        onClick={() => setCurrentView('detail_balance')}
                        whileHover={{ scale: 1.02 }}
                        className="text-left bg-surface p-6 rounded-2xl border border-slate-700 shadow-xl relative overflow-hidden group w-full"
                    >
                        <div className="relative z-10">
                            <p className="text-muted text-sm font-medium mb-1">Saldo Atual</p>
                            <h3 className="text-3xl font-bold text-white">{formatCurrency(stats.balance)}</h3>
                        </div>
                        <div className="mt-4 flex items-center justify-between text-sm text-primary">
                            <div className="flex items-center gap-2">
                                <Wallet size={16} />
                                <span>Disponível</span>
                            </div>
                        </div>
                    </motion.button>

                    <div className="grid grid-cols-2 md:grid-cols-1 gap-4">
                        <motion.button 
                            onClick={() => setCurrentView('detail_income')}
                            whileHover={{ scale: 1.02 }}
                            className="text-left bg-surface p-4 rounded-2xl border border-slate-700 shadow-xl w-full group"
                        >
                            <p className="text-muted text-[10px] font-bold uppercase mb-1">Receitas</p>
                            <h3 className="text-lg font-bold text-emerald-400">{formatCurrency(stats.income)}</h3>
                        </motion.button>

                        <motion.button 
                            onClick={() => setCurrentView('detail_expense')}
                            whileHover={{ scale: 1.02 }}
                            className="text-left bg-surface p-4 rounded-2xl border border-slate-700 shadow-xl w-full group"
                        >
                            <p className="text-muted text-[10px] font-bold uppercase mb-1">Despesas</p>
                            <h3 className="text-lg font-bold text-rose-400">{formatCurrency(stats.expense)}</h3>
                        </motion.button>
                    </div>
                </div>

                {/* SCORE & CHART SECTIONS OMITTED FOR BREVITY AS THEY ARE UNCHANGED IN LOGIC */}
                 {/* ... Score Section ... */}
                <div className="bg-surface rounded-3xl border border-slate-700 shadow-2xl relative overflow-hidden p-0 group">
                    {/* Header Strip */}
                    <div className="bg-slate-900/50 p-4 border-b border-slate-700 flex justify-between items-center backdrop-blur-md relative z-20">
                         <h3 className="text-base font-bold text-slate-200 flex items-center gap-2">
                            <Gauge className="text-primary" size={18} />
                            Score Financeiro
                        </h3>
                        <div className="flex items-center gap-2">
                             {scoreData?.providerUsed && (
                                <span className="text-[10px] bg-slate-800 border border-slate-600 px-2 py-0.5 rounded text-slate-400 flex items-center gap-1 uppercase tracking-wider">
                                    <Zap size={10} className={scoreData.providerUsed === 'openai' ? 'text-emerald-400' : 'text-blue-400'} />
                                    AI
                                </span>
                            )}
                            <button 
                                onClick={handleCalculateScore} 
                                disabled={loadingScore} 
                                className="p-1.5 bg-slate-800 rounded-lg hover:bg-slate-700 transition-colors border border-slate-700 text-slate-400 hover:text-white"
                                title="Recalcular Score"
                            >
                                <RotateCw size={14} className={loadingScore ? 'animate-spin' : ''} />
                            </button>
                        </div>
                    </div>

                    <div className="p-6 md:p-8 relative z-10">
                        <div className="flex flex-col md:flex-row items-center gap-8 md:gap-12">
                            
                            {/* Score Circle */}
                            <div className="relative shrink-0 flex flex-col items-center">
                                <div className="relative w-40 h-40 md:w-48 md:h-48">
                                    {/* Outer Ring (Bg) */}
                                    <svg className="w-full h-full transform -rotate-90 drop-shadow-2xl" viewBox="0 0 100 100">
                                        <circle 
                                            cx="50" cy="50" r="45" 
                                            className="stroke-slate-800/50" 
                                            strokeWidth="8" 
                                            fill="transparent" 
                                            strokeLinecap="round"
                                        />
                                        {/* Progress Ring */}
                                        <motion.circle 
                                            cx="50" cy="50" r="45" 
                                            strokeWidth="8" 
                                            fill="transparent"
                                            strokeLinecap="round"
                                            className={`stroke-current ${scoreData ? getScoreColor(scoreData.score) : 'text-slate-700'}`}
                                            initial={{ strokeDasharray: scoreCircumference, strokeDashoffset: scoreCircumference }} 
                                            animate={{ 
                                                strokeDasharray: scoreCircumference, 
                                                strokeDashoffset: scoreData ? scoreCircumference - (scoreData.score / 1000) * scoreCircumference : scoreCircumference
                                            }}
                                            transition={{ duration: 2, ease: "easeOut" }}
                                        />
                                    </svg>
                                    
                                    {/* Inner Content */}
                                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                                        <div className="flex flex-col items-center">
                                            <span className={`text-4xl md:text-5xl font-bold tracking-tighter ${scoreData ? getScoreColor(scoreData.score) : 'text-slate-600'}`}>
                                                {scoreData ? scoreData.score : '---'}
                                            </span>
                                            <span className="text-xs text-slate-500 font-bold uppercase tracking-widest mt-1">de 1000</span>
                                        </div>
                                    </div>

                                    {/* Glowing Effect underneath */}
                                    {scoreData && (
                                        <div className={`absolute inset-0 blur-3xl opacity-20 rounded-full ${getScoreGradient(scoreData.score).replace('from-', 'bg-')}`}></div>
                                    )}
                                </div>
                                
                                {scoreData && (
                                    <motion.div 
                                        initial={{ opacity: 0, y: 10 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        transition={{ delay: 0.5 }}
                                        className={`mt-4 px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider border bg-opacity-10 border-opacity-20 ${
                                            scoreData.rating === 'Excelente' ? 'bg-emerald-500 text-emerald-400 border-emerald-500' : 
                                            scoreData.rating === 'Bom' ? 'bg-blue-500 text-blue-400 border-blue-500' : 
                                            scoreData.rating === 'Regular' ? 'bg-yellow-500 text-yellow-400 border-yellow-500' :
                                            'bg-rose-500 text-rose-400 border-rose-500'
                                        }`}
                                    >
                                        {scoreData.rating}
                                    </motion.div>
                                )}
                            </div>

                            {/* Analysis Text REMOVED, only Factors remain */}
                            <div className="flex-1 w-full flex flex-col justify-center">
                                {scoreData ? (
                                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
                                        
                                        <div className="flex flex-col gap-2">
                                            <p className="text-slate-500 text-[10px] font-bold uppercase tracking-widest mb-1 text-center md:text-left">Fatores de Impacto</p>
                                            <div className="flex flex-wrap gap-2 justify-center md:justify-start">
                                                {scoreData.factors.map((factor, idx) => (
                                                    <span 
                                                        key={idx} 
                                                        className={`text-xs px-3 py-2 rounded-lg border font-medium flex items-center gap-2 ${
                                                            factor.impact === 'positive' ? 'text-emerald-400 border-emerald-500/20 bg-emerald-500/5' : 
                                                            factor.impact === 'negative' ? 'text-rose-400 border-rose-500/20 bg-rose-500/5' : 
                                                            'text-slate-400 border-slate-700 bg-slate-800'
                                                        }`}
                                                    >
                                                        {factor.impact === 'positive' && <ArrowUpCircle size={14} />}
                                                        {factor.impact === 'negative' && <ArrowDownCircle size={14} />}
                                                        {factor.name}
                                                    </span>
                                                ))}
                                            </div>
                                        </div>

                                        <div className="bg-slate-900/40 p-3 rounded-xl border border-white/5 text-xs text-slate-400 mt-2 text-center md:text-left">
                                            <p>O score é calculado baseando-se no seu histórico de transações e hábitos financeiros recentes.</p>
                                        </div>

                                    </motion.div>
                                ) : (
                                    <div className="flex flex-col items-center md:items-start text-slate-500 gap-3">
                                        <div className="p-3 bg-slate-800 rounded-full">
                                            <Sparkles size={24} className="text-slate-600" />
                                        </div>
                                        <div className="space-y-1 text-center md:text-left">
                                            <p className="font-medium text-slate-300">Aguardando dados...</p>
                                            <p className="text-sm">Adicione transações para desbloquear seu Score Financeiro.</p>
                                        </div>
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>

                    {/* Decorative Background Blob */}
                    <div className="absolute right-0 top-0 w-64 h-64 bg-gradient-to-br from-indigo-500/10 to-purple-500/10 rounded-full blur-[100px] pointer-events-none -translate-y-1/2 translate-x-1/2"></div>
                </div>

                {/* GRÁFICO */}
                <div className="bg-surface p-6 rounded-2xl border border-slate-700 shadow-xl">
                    <div className="flex items-center justify-between mb-6">
                        <h3 className="text-lg font-bold text-slate-200 flex items-center gap-2">
                            <TrendingUp className="text-primary" size={20}/>
                            Atividade Recente
                        </h3>
                    </div>
                    
                    <div className="h-[250px] w-full mb-6">
                        <ResponsiveContainer width="100%" height="100%">
                            <AreaChart data={chartData}>
                                <defs>
                                    <linearGradient id="colorIncome" x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="5%" stopColor="#10b981" stopOpacity={0.2}/>
                                        <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                                    </linearGradient>
                                    <linearGradient id="colorExpense" x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="5%" stopColor="#ef4444" stopOpacity={0.2}/>
                                        <stop offset="95%" stopColor="#ef4444" stopOpacity={0}/>
                                    </linearGradient>
                                </defs>
                                <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
                                <XAxis dataKey="name" stroke="#94a3b8" fontSize={10} tickLine={false} axisLine={false} />
                                <YAxis hide />
                                <Area type="monotone" dataKey="income" stroke="#10b981" strokeWidth={2} fillOpacity={1} fill="url(#colorIncome)" />
                                <Area type="monotone" dataKey="expense" stroke="#ef4444" strokeWidth={2} fillOpacity={1} fill="url(#colorExpense)" />
                            </AreaChart>
                        </ResponsiveContainer>
                    </div>

                    {/* AI Tip */}
                    <div className="bg-slate-900/50 rounded-xl p-4 border border-slate-700/50 flex items-start gap-3">
                        <Sparkles className="text-indigo-400 mt-1 shrink-0" size={18} />
                        <div>
                            <h4 className="text-xs font-bold text-indigo-300 mb-1 uppercase tracking-wider">Insight AI</h4>
                            <p className="text-xs text-slate-400 leading-relaxed">
                                {safeCashFlowTip || "Aguardando processamento inteligente dos seus dados recentes..."}
                            </p>
                        </div>
                    </div>
                </div>

                <div className="flex items-center justify-center gap-4 text-slate-500 text-xs font-medium py-4">
                    <div className="flex items-center gap-1"><ChevronLeft size={14} className="animate-pulse" />Análise</div>
                    <div className="w-1 h-1 rounded-full bg-slate-700"></div>
                    <div className="flex items-center gap-1">Menu<ChevronRight size={14} className="animate-pulse" /></div>
                </div>
            </motion.div>
        )}
        
        {/* ... Rest of views ... */}
        {currentView === 'extended' && (
            <motion.div
                key="extended"
                custom={direction}
                variants={variants}
                initial="enter"
                animate="center"
                exit="exit"
                transition={{ type: "spring", stiffness: 300, damping: 30 }}
                className="w-full h-full pb-20"
                drag="x"
                dragConstraints={{ left: 0, right: 0 }}
                dragElastic={0.05}
                onDragEnd={handleDragEnd}
                style={{ touchAction: "pan-y" }}
            >
                <ExtendedAnalytics 
                    transactions={transactions} 
                    goals={goals} 
                    onBack={() => setCurrentView('default')} 
                />
            </motion.div>
        )}

        {currentView === 'menu_grid' && (
            <motion.div
                key="menu_grid"
                custom={direction}
                variants={variants}
                initial="enter"
                animate="center"
                exit="exit"
                transition={{ type: "spring", stiffness: 300, damping: 30 }}
                className="w-full space-y-8 pb-20 px-4 pt-4"
                drag="x"
                dragConstraints={{ left: 0, right: 0 }}
                dragElastic={0.05}
                onDragEnd={handleDragEnd}
                style={{ touchAction: "pan-y" }}
            >
                <div className="flex items-center gap-4 mb-2">
                    <button onClick={() => setCurrentView('default')} className="p-2 bg-slate-800 rounded-full hover:bg-slate-700 transition-colors">
                        <ArrowLeft size={24} className="text-slate-200" />
                    </button>
                    <h2 className="text-2xl font-bold text-white">Navegação Rápida</h2>
                </div>

                <div className="grid grid-cols-2 gap-4">
                    {menuItems.map((item, idx) => (
                        <motion.button
                            key={item.id}
                            initial={{ opacity: 0, scale: 0.9, y: 20 }}
                            animate={{ opacity: 1, scale: 1, y: 0 }}
                            transition={{ delay: idx * 0.05 }}
                            whileHover={{ scale: 1.05, backgroundColor: 'rgba(30, 41, 59, 0.8)' }}
                            whileTap={{ scale: 0.95 }}
                            onClick={() => {
                                if (setActiveTab) {
                                    setActiveTab(item.id);
                                    setCurrentView('default');
                                }
                            }}
                            className="bg-surface/50 backdrop-blur-md border border-slate-700 p-6 rounded-3xl flex flex-col items-center gap-3 shadow-xl group"
                        >
                            <div className={`p-4 rounded-2xl bg-slate-800 group-hover:bg-slate-700 transition-colors ${item.color}`}>
                                <item.icon size={32} />
                            </div>
                            <span className="font-bold text-slate-200 text-sm">{item.label}</span>
                        </motion.button>
                    ))}
                    
                    <motion.div
                        initial={{ opacity: 0, scale: 0.9, y: 20 }}
                        animate={{ opacity: 1, scale: 1, y: 0 }}
                        transition={{ delay: 0.4 }}
                        className="bg-gradient-to-br from-indigo-900/40 to-slate-900 border border-indigo-500/20 p-6 rounded-3xl flex flex-col items-center justify-center gap-2 col-span-2 mt-4"
                    >
                        <Sparkles className="text-indigo-400" size={24} />
                        <p className="text-xs text-indigo-200 text-center font-medium">Explore as funcionalidades avançadas<br/>do Capitalyx Intelligence.</p>
                    </motion.div>
                </div>

                <div className="flex items-center justify-center gap-1 text-slate-600 text-[10px] font-bold uppercase tracking-widest mt-8">
                    <ChevronLeft size={12} /> Deslize para voltar
                </div>
            </motion.div>
        )}

      </AnimatePresence>
      {/* Page Indicators unchanged */}
       {(currentView === 'default' || currentView === 'extended' || currentView === 'menu_grid') && (
        <div className="flex justify-center w-full mt-auto absolute bottom-4 left-0 pointer-events-none">
            <div className="flex gap-2 bg-black/40 backdrop-blur-md px-3 py-1.5 rounded-full border border-white/5 shadow-2xl">
                <button 
                  onClick={() => setCurrentView('extended')}
                  className={`w-1.5 h-1.5 rounded-full transition-all duration-300 ${currentView === 'extended' ? 'bg-white w-4' : 'bg-slate-600'}`} 
                />
                <button 
                  onClick={() => setCurrentView('default')}
                  className={`w-1.5 h-1.5 rounded-full transition-all duration-300 ${currentView === 'default' ? 'bg-white w-4' : 'bg-slate-600'}`} 
                />
                <button 
                  onClick={() => setCurrentView('menu_grid')}
                  className={`w-1.5 h-1.5 rounded-full transition-all duration-300 ${currentView === 'menu_grid' ? 'bg-white w-4' : 'bg-slate-600'}`} 
                />
            </div>
        </div>
      )}
    </div>
  );
};

export default Dashboard;
