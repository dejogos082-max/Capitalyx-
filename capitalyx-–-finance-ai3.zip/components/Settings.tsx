
import React, { useState } from 'react';
import { AppSettings, UserProfile } from '../types';
import { 
  Settings as SettingsIcon, Monitor, Eye, User, Zap, Maximize, 
  Layers, ToggleLeft, ToggleRight, Check, Sliders, Smartphone, TestTube2, Sparkles
} from 'lucide-react';
import { motion } from 'framer-motion';

interface SettingsProps {
  user: UserProfile;
  settings: AppSettings;
  onUpdateSettings: (newSettings: AppSettings) => void;
  onShowToast: (message: string) => void;
}

const Settings: React.FC<SettingsProps> = ({ user, settings, onUpdateSettings, onShowToast }) => {
  const [activeTab, setActiveTab] = useState<'performance' | 'visual' | 'account'>('performance');

  const tabs = [
    { id: 'performance', label: 'Desempenho', icon: Monitor },
    { id: 'visual', label: 'Visual', icon: Eye },
    { id: 'account', label: 'Conta', icon: User },
  ];

  const updateSetting = (category: keyof AppSettings, key: string, value: any) => {
      const newSettings = {
          ...settings,
          [category]: {
              ...(settings[category] as any),
              [key]: value
          }
      };
      onUpdateSettings(newSettings);
      onShowToast("Configuração atualizada com sucesso!");
  };

  return (
    <div className="max-w-4xl mx-auto pb-10">
      <h2 className="text-2xl font-bold text-white flex items-center gap-2 mb-6">
        <SettingsIcon className="text-slate-400" /> Configurações do Sistema
      </h2>

      <div className="bg-surface rounded-3xl border border-slate-700 overflow-hidden shadow-2xl flex flex-col md:flex-row min-h-[600px]">
        {/* Sidebar de Abas */}
        <div className="w-full md:w-64 bg-slate-900/50 border-b md:border-b-0 md:border-r border-slate-700 p-4">
          <div className="space-y-2">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${activeTab === tab.id ? 'bg-primary text-white shadow-lg' : 'text-slate-400 hover:bg-slate-800'}`}
              >
                <tab.icon size={18} /> {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Conteúdo das Abas */}
        <div className="flex-1 p-6 md:p-10">
          <motion.div key={activeTab} initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} className="space-y-8">
            
            {/* --- PERFORMANCE TAB --- */}
            {activeTab === 'performance' && (
                <div className="space-y-8">
                    <section>
                        <h3 className="text-lg font-semibold text-white flex items-center gap-2 mb-4">
                            <Zap size={20} className="text-yellow-500" /> Otimização de Interface
                        </h3>
                        <p className="text-sm text-slate-400 mb-6">Ajuste o comportamento visual para melhor fluidez no seu dispositivo.</p>
                        
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                            {(['low', 'medium', 'high'] as const).map(opt => (
                                <button 
                                    key={opt} 
                                    onClick={() => updateSetting('performance', 'fps', opt)} 
                                    className={`p-4 rounded-2xl border text-sm font-bold transition-all flex flex-col items-center gap-2 ${settings.performance.fps === opt ? 'bg-primary/20 border-primary text-primary' : 'bg-slate-800 border-slate-700 text-slate-400 hover:border-slate-500'}`}
                                >
                                    <span className="uppercase">{opt === 'low' ? 'Bateria' : opt === 'medium' ? 'Equilibrado' : 'Máximo'}</span>
                                    <span className="text-[10px] opacity-60 font-normal">{opt === 'low' ? '30 FPS' : opt === 'medium' ? '60 FPS' : '120 FPS+'}</span>
                                </button>
                            ))}
                        </div>
                    </section>

                    <section className="bg-slate-800/40 p-6 rounded-2xl border border-slate-700">
                        <div className="flex items-center justify-between">
                            <div className="flex items-center gap-4">
                                <div className="p-3 bg-blue-500/20 rounded-xl text-blue-400">
                                    <Maximize size={24} />
                                </div>
                                <div>
                                    <h4 className="font-bold text-slate-200">Modo de Alta Performance</h4>
                                    <p className="text-xs text-slate-500">Desativa sombras e efeitos de blur para economizar CPU.</p>
                                </div>
                            </div>
                            <button 
                                onClick={() => updateSetting('performance', 'highPerformanceMode', !settings.performance.highPerformanceMode)}
                                className={`w-14 h-7 rounded-full relative transition-colors ${settings.performance.highPerformanceMode ? 'bg-primary' : 'bg-slate-600'}`}
                            >
                                <div className={`w-5 h-5 bg-white rounded-full absolute top-1 transition-transform ${settings.performance.highPerformanceMode ? 'left-8' : 'left-1'}`} />
                            </button>
                        </div>
                    </section>
                </div>
            )}

            {/* --- VISUAL TAB --- */}
            {activeTab === 'visual' && (
                <div className="space-y-8">
                    <section>
                        <h3 className="text-lg font-semibold text-white flex items-center gap-2 mb-4">
                            <Eye size={20} className="text-purple-500" /> Temas de Cores
                        </h3>
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                            {[
                                { id: 'default', label: 'Padrão', color: 'bg-blue-600' },
                                { id: 'cyberpunk', label: 'Cyber', color: 'bg-fuchsia-600' },
                                { id: 'ocean', label: 'Oceano', color: 'bg-cyan-600' },
                                { id: 'sunset', label: 'Sunset', color: 'bg-orange-600' }
                            ].map(t => (
                                <button 
                                    key={t.id} 
                                    onClick={() => updateSetting('visual', 'theme', t.id)} 
                                    className={`group flex flex-col items-center gap-3 p-3 rounded-2xl border transition-all ${settings.visual.theme === t.id ? 'border-primary bg-primary/10 shadow-lg shadow-primary/10' : 'border-slate-700 bg-slate-800/50 hover:border-slate-500'}`}
                                >
                                    <div className={`w-full h-12 rounded-xl ${t.color} flex items-center justify-center`}>
                                        {settings.visual.theme === t.id && <Check size={24} className="text-white" />}
                                    </div>
                                    <span className="text-xs font-bold text-slate-300 uppercase">{t.label}</span>
                                </button>
                            ))}
                        </div>
                    </section>

                    <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {/* Escala */}
                        <div className="bg-slate-800/40 p-6 rounded-2xl border border-slate-700">
                            <h4 className="font-bold text-slate-200 flex items-center gap-2 mb-4">
                                <Sliders size={18} className="text-blue-400" /> Escala da Interface
                            </h4>
                            <input 
                                type="range" 
                                min="0.8" 
                                max="1.2" 
                                step="0.05"
                                value={settings.visual.scale}
                                onChange={(e) => updateSetting('visual', 'scale', parseFloat(e.target.value))}
                                className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-primary"
                            />
                            <div className="flex justify-between mt-2 text-[10px] text-slate-500 font-bold">
                                <span>MIN (80%)</span>
                                <span className="text-primary">{Math.round(settings.visual.scale * 100)}%</span>
                                <span>MAX (120%)</span>
                            </div>
                        </div>

                        {/* Modo de Layout */}
                        <div className="bg-slate-800/40 p-6 rounded-2xl border border-slate-700">
                            <h4 className="font-bold text-slate-200 flex items-center gap-2 mb-4">
                                <Layers size={18} className="text-emerald-400" /> Modo de Layout
                            </h4>
                            <div className="flex bg-slate-900 p-1 rounded-xl">
                                {(['minimal', 'default', 'advanced'] as const).map(mode => (
                                    <button 
                                        key={mode} 
                                        onClick={() => updateSetting('visual', 'layoutMode', mode)}
                                        className={`flex-1 py-2 text-[10px] font-bold rounded-lg uppercase transition-all ${settings.visual.layoutMode === mode ? 'bg-primary text-white shadow-md' : 'text-slate-500 hover:text-slate-300'}`}
                                    >
                                        {mode}
                                    </button>
                                ))}
                            </div>
                        </div>
                    </section>
                </div>
            )}

            {/* --- ACCOUNT TAB --- */}
            {activeTab === 'account' && (
                <div className="space-y-6">
                    <h3 className="text-lg font-semibold text-white flex items-center gap-2 mb-4">
                        <User size={20} className="text-cyan-500" /> Gestão de Conta & Segurança
                    </h3>
                    
                    <div className="space-y-4">
                        {/* Auto Login */}
                        <div className="bg-slate-800/40 p-5 rounded-2xl border border-slate-700 flex items-center justify-between">
                            <div className="flex items-center gap-4">
                                <Smartphone size={20} className="text-slate-400" />
                                <div>
                                    <h4 className="font-medium text-slate-200">Login Automático</h4>
                                    <p className="text-xs text-slate-500">Lembra suas credenciais neste navegador.</p>
                                </div>
                            </div>
                            <button 
                                onClick={() => updateSetting('account', 'autoLogin', !settings.account.autoLogin)}
                                className={`w-12 h-6 rounded-full relative transition-colors ${settings.account.autoLogin ? 'bg-cyan-500' : 'bg-slate-600'}`}
                            >
                                <div className={`w-4 h-4 bg-white rounded-full absolute top-1 transition-transform ${settings.account.autoLogin ? 'left-7' : 'left-1'}`} />
                            </button>
                        </div>

                        {/* Beta Toggle */}
                        <div className="bg-indigo-500/5 p-5 rounded-2xl border border-indigo-500/20 flex items-center justify-between">
                            <div className="flex items-center gap-4">
                                <TestTube2 size={20} className="text-indigo-400" />
                                <div>
                                    <h4 className="font-medium text-indigo-300">Modo Beta Tester</h4>
                                    <p className="text-xs text-indigo-200/50">Habilita ferramentas experimentais e novos gráficos.</p>
                                </div>
                            </div>
                            <button 
                                onClick={() => updateSetting('account', 'betaMode', !settings.account.betaMode)}
                                className={`w-12 h-6 rounded-full relative transition-colors ${settings.account.betaMode ? 'bg-indigo-600' : 'bg-slate-600'}`}
                            >
                                <div className={`w-4 h-4 bg-white rounded-full absolute top-1 transition-transform ${settings.account.betaMode ? 'left-7' : 'left-1'}`} />
                            </button>
                        </div>

                        {/* Show Beta Switch */}
                        <div className="bg-slate-900/50 p-5 rounded-2xl border border-slate-800 flex items-center justify-between">
                            <div className="flex items-center gap-4">
                                <Sparkles size={20} className="text-slate-500" />
                                <div>
                                    <h4 className="font-medium text-slate-400">Atalho Beta no Menu</h4>
                                    <p className="text-xs text-slate-600">Exibe o interruptor Beta na barra lateral.</p>
                                </div>
                            </div>
                            <button 
                                onClick={() => updateSetting('visual', 'showHeaderBetaSwitch', !settings.visual.showHeaderBetaSwitch)}
                                className={`w-12 h-6 rounded-full relative transition-colors ${settings.visual.showHeaderBetaSwitch ? 'bg-primary/50' : 'bg-slate-700'}`}
                            >
                                <div className={`w-4 h-4 bg-white rounded-full absolute top-1 transition-transform ${settings.visual.showHeaderBetaSwitch ? 'left-7' : 'left-1'}`} />
                            </button>
                        </div>
                    </div>
                </div>
            )}
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default Settings;
