
import React, { useState, useEffect } from 'react';
import { UserProfile, SystemConfig, IntegrityLog, AIUsageStats, IntegrityState, AIConfig, AIProvider } from '../types';
import { 
  toggleSystemMaintenance, 
  subscribeToSystemStatus, 
  subscribeToIntegrityLogs, 
  subscribeToAIStats,
  subscribeToIntegrityConfig,
  restartAIServices,
  forceIntegrityCheck,
  updateIntegrityState,
  subscribeToAIConfig,
  toggleAIProvider,
  performSystemFactoryReset,
  toggleGlobalBetaMode
} from '../services/firebase';
import { executeAIAutoFix } from '../services/aiMonitor';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  ShieldCheck, Activity, AlertOctagon, Terminal, Power, RefreshCw, 
  Wifi, WifiOff, Bot, FileCode, Play, Bug, HardDrive, Cpu, Zap, Trash2, AlertTriangle
} from 'lucide-react';

interface AdminPanelProps {
  user: UserProfile;
}

const AdminPanel: React.FC<AdminPanelProps> = ({ user }) => {
  const [systemConfig, setSystemConfig] = useState<SystemConfig | null>(null);
  const [integrityLogs, setIntegrityLogs] = useState<IntegrityLog[]>([]);
  const [aiStats, setAiStats] = useState<AIUsageStats | null>(null);
  const [integrityConfig, setIntegrityConfig] = useState<IntegrityState | null>(null);
  const [aiConfig, setAiConfig] = useState<AIConfig | null>(null);
  
  const [isToggling, setIsToggling] = useState(false);
  const [isRestarting, setIsRestarting] = useState(false);
  const [isSwitchingAI, setIsSwitchingAI] = useState(false);
  const [criticalError, setCriticalError] = useState<IntegrityLog | null>(null);
  const [isFixing, setIsFixing] = useState(false);
  
  // Reset States
  const [showResetModal, setShowResetModal] = useState(false);
  const [resetConfirmation, setResetConfirmation] = useState('');
  const [isResetting, setIsResetting] = useState(false);

  useEffect(() => {
    const unsubSys = subscribeToSystemStatus(setSystemConfig);
    const unsubLogs = subscribeToIntegrityLogs((logs) => {
        setIntegrityLogs(logs);
        if (logs.length > 0) {
            const latest = logs[0];
            const timeDiff = Date.now() - latest.timestamp;
            if (latest.status === 'error' && timeDiff < 60000 && latest.step !== 'FIX_ATTEMPT' && latest.step !== 'SYSTEM_PATCH') {
                 setCriticalError(latest);
            }
        }
    });
    const unsubAI = subscribeToAIStats(setAiStats);
    const unsubConf = subscribeToIntegrityConfig(setIntegrityConfig);
    const unsubAIConf = subscribeToAIConfig(setAiConfig);
    
    return () => { unsubSys(); unsubLogs(); unsubAI(); unsubConf(); unsubAIConf(); };
  }, []);

  const handleMaintenanceToggle = async () => {
    if (!systemConfig) return;
    setIsToggling(true);
    try { await toggleSystemMaintenance(user.uid, !systemConfig.maintenanceMode); } catch (e) { console.error(e); } 
    finally { setIsToggling(false); }
  };

  const handleRestartAI = async () => {
      if(confirm("Confirmar reinício dos serviços de IA?")) {
          setIsRestarting(true);
          await restartAIServices();
          setTimeout(() => setIsRestarting(false), 1000);
      }
  };

  const handleForceCheck = async () => await forceIntegrityCheck();

  const handleAISwitch = async (provider: AIProvider) => {
      if (aiConfig?.activeProvider === provider) return;
      setIsSwitchingAI(true);
      try { await toggleAIProvider(provider, user.uid); } catch (e) { console.error(e); }
      finally { setIsSwitchingAI(false); }
  };

  const handleFixCriticalError = async () => {
      if (!criticalError) return;
      setIsFixing(true);
      try {
          await executeAIAutoFix("CRITICAL_ERROR_RESPONSE");
          await updateIntegrityState({ status: 'idle', isPaused: false });
          setCriticalError(null);
      } catch (e) { console.error("Failed to fix", e); } finally { setIsFixing(false); }
  };

  const handleFactoryReset = async () => {
      if (resetConfirmation !== 'DELETAR-TUDO') return;
      setIsResetting(true);
      try {
          await performSystemFactoryReset(user.uid);
          setShowResetModal(false);
          setResetConfirmation('');
          alert("Sistema resetado com sucesso. Todos os dados foram apagados.");
          window.location.reload();
      } catch (e) {
          console.error("Reset failed", e);
          alert("Falha ao resetar sistema. Verifique permissões.");
      } finally {
          setIsResetting(false);
      }
  };

  const handleToggleGlobalBeta = async () => {
      if (!systemConfig) return;
      try {
          await toggleGlobalBetaMode(user.uid, !systemConfig.forceGlobalBeta);
      } catch (e) { console.error(e); }
  };

  if (!user.isAdministrator) {
    return <div className="p-6 text-center text-rose-500 font-bold">Acesso Negado</div>;
  }

  const getProviderLabel = () => {
      switch(aiConfig?.activeProvider) {
          case 'openai': return 'ChatGPT (GPT-4o Mini)';
          default: return 'Gemini Flash';
      }
  };

  const systemStats = [
    { label: 'Status', value: systemConfig?.maintenanceMode ? 'Manutenção' : 'Online', color: systemConfig?.maintenanceMode ? 'text-rose-400' : 'text-emerald-400', icon: systemConfig?.maintenanceMode ? WifiOff : Wifi },
    { label: 'AI Engine', value: getProviderLabel(), color: 'text-cyan-400', icon: Cpu },
    { label: 'Patch', value: systemConfig?.activePatchVersion || '1.0.0', color: 'text-purple-400', icon: FileCode },
    { label: 'Ciclo', value: integrityConfig?.status === 'running' ? 'Executando' : 'Aguardando', color: integrityConfig?.status === 'running' ? 'text-yellow-400' : 'text-emerald-400', icon: Activity }, 
  ];

  return (
    <div className="space-y-8 pb-10 relative">
      
      {/* --- MODAL DE ERRO CRÍTICO --- */}
      <AnimatePresence>
        {criticalError && (
            <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
                <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }} className="bg-surface border-2 border-rose-500 rounded-2xl p-6 max-w-lg w-full">
                    <div className="flex items-start gap-4 mb-4">
                        <Bug size={32} className="text-rose-500" />
                        <div><h2 className="text-2xl font-bold text-white">ERRO CRÍTICO</h2><p className="text-rose-400 text-sm font-mono">CRITICAL_FAILURE</p></div>
                    </div>
                    <div className="bg-slate-950 p-4 rounded-xl border border-rose-500/30 text-xs text-rose-200 mb-6 max-h-32 overflow-y-auto font-mono"><p>{criticalError.details}</p></div>
                    <div className="flex gap-3">
                        <button onClick={() => setCriticalError(null)} className="flex-1 py-3 rounded-xl border border-slate-600 text-slate-300">Ignorar</button>
                        <button onClick={handleFixCriticalError} disabled={isFixing} className="flex-1 py-3 rounded-xl bg-rose-600 text-white font-bold flex justify-center gap-2">{isFixing ? <RefreshCw className="animate-spin"/> : <HardDrive />} Corrigir</button>
                    </div>
                </motion.div>
            </div>
        )}
      </AnimatePresence>

      {/* --- MODAL DE FACTORY RESET --- */}
      <AnimatePresence>
        {showResetModal && (
            <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/90 backdrop-blur-md">
                <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }} className="bg-surface border-2 border-red-600 rounded-2xl p-8 max-w-md w-full shadow-[0_0_50px_rgba(220,38,38,0.5)]">
                    <div className="flex flex-col items-center text-center mb-6">
                        <div className="w-20 h-20 bg-red-600/20 rounded-full flex items-center justify-center mb-4 border-2 border-red-600 animate-pulse">
                            <AlertTriangle size={40} className="text-red-500" />
                        </div>
                        <h2 className="text-2xl font-bold text-white">ZONA DE PERIGO</h2>
                        <p className="text-red-400 text-sm font-mono mt-1">SYSTEM_WIPE_CONFIRMATION</p>
                    </div>
                    
                    <p className="text-slate-300 text-sm mb-6 text-center leading-relaxed">
                        Esta ação irá <strong>APAGAR PERMANENTEMENTE</strong> todos os usuários, transações, logs e configurações do banco de dados. 
                        <br/><br/>
                        <span className="text-red-400">Isso não pode ser desfeito.</span>
                    </p>

                    <div className="space-y-4">
                        <div>
                            <label className="text-xs text-slate-500 uppercase font-bold block mb-2">Digite "DELETAR-TUDO" para confirmar</label>
                            <input 
                                type="text" 
                                value={resetConfirmation}
                                onChange={(e) => setResetConfirmation(e.target.value)}
                                className="w-full bg-black border border-red-900 rounded-lg p-3 text-red-500 font-mono text-center focus:outline-none focus:border-red-500"
                                placeholder="DELETAR-TUDO"
                            />
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                            <button 
                                onClick={() => setShowResetModal(false)} 
                                className="py-3 rounded-xl border border-slate-600 text-slate-300 hover:bg-slate-800 transition-colors"
                            >
                                Cancelar
                            </button>
                            <button 
                                onClick={handleFactoryReset} 
                                disabled={resetConfirmation !== 'DELETAR-TUDO' || isResetting} 
                                className="py-3 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold flex justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-lg shadow-red-900/40"
                            >
                                {isResetting ? <RefreshCw className="animate-spin"/> : <Trash2 />} 
                                RESETAR
                            </button>
                        </div>
                    </div>
                </motion.div>
            </div>
        )}
      </AnimatePresence>

      <div className="bg-gradient-to-r from-rose-900/80 to-slate-900 p-8 rounded-3xl border border-rose-500/30 relative overflow-hidden shadow-2xl">
        <div className="relative z-10 flex justify-between items-center">
           <div>
             <div className="flex items-center gap-3 mb-2">
                <ShieldCheck className="text-white" size={24} />
                <span className="bg-rose-500/20 text-rose-300 border border-rose-500/30 px-3 py-0.5 rounded-full text-xs font-bold uppercase">ROOT ACCESS</span>
             </div>
             <h2 className="text-3xl font-bold text-white">Painel Administrativo</h2>
           </div>
           <Terminal size={80} className="text-rose-500 opacity-30 hidden md:block" />
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {systemStats.map((stat, idx) => (
          <motion.div key={idx} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: idx * 0.1 }} className="bg-surface border border-slate-700 p-5 rounded-2xl shadow-lg">
             <div className="flex justify-between items-start mb-2"><span className="text-slate-400 text-sm">{stat.label}</span><stat.icon size={18} className="text-slate-500" /></div>
             <div className={`text-xl font-bold truncate ${stat.color}`}>{stat.value}</div>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
         <div className="lg:col-span-2 space-y-8">
             {/* SYSTEM LOGS */}
             <div className="bg-slate-950 rounded-2xl border border-slate-800 p-6 flex flex-col h-[400px]">
                <div className="flex justify-between items-center mb-4 border-b border-slate-800 pb-4">
                    <h3 className="text-slate-300 font-bold flex items-center gap-2"><Activity size={18} className="text-blue-500" /> System Logs</h3>
                    <div className="flex items-center gap-3">
                        <div className={`px-2 py-1 rounded text-xs font-bold ${integrityConfig?.isPaused ? 'bg-yellow-500/20 text-yellow-500' : 'bg-green-500/20 text-green-500'}`}>{integrityConfig?.isPaused ? 'PAUSADO' : 'ATIVO'}</div>
                        <button onClick={handleForceCheck} className="bg-blue-600 px-3 py-1 rounded-lg text-xs font-bold flex items-center gap-1"><Play size={12} /> Forçar</button>
                    </div>
                </div>

                <div className="flex-1 overflow-y-auto bg-black/40 rounded-xl p-4 font-mono text-xs border border-slate-800 custom-scrollbar">
                    {integrityLogs.map((log) => (
                        <div key={log.id} className="mb-3 border-l-2 border-slate-700 pl-3 py-1">
                            <div className="flex items-center gap-2 mb-1">
                                <span className="text-slate-500">[{new Date(log.timestamp).toLocaleTimeString()}]</span>
                                <span className={`font-bold ${log.status === 'ok' ? 'text-emerald-500' : log.status === 'warning' ? 'text-yellow-500' : 'text-rose-500'}`}>{log.step}</span>
                                {log.provider && <span className="text-[10px] bg-slate-800 px-1 rounded text-slate-400">{log.provider}</span>}
                            </div>
                            <p className="text-slate-300">{log.details}</p>
                        </div>
                    ))}
                </div>
             </div>
         </div>

         <div className="space-y-6">
            {/* CONTROLS */}
            <div className="bg-surface border border-slate-700 rounded-2xl p-6">
                <h3 className="text-white font-bold mb-4 flex items-center gap-2"><AlertOctagon size={18} className="text-rose-500" /> Controles</h3>
                <div className="bg-slate-900 p-4 rounded-xl border border-slate-700 mb-4 space-y-3">
                    <button onClick={handleMaintenanceToggle} disabled={isToggling} className={`w-full py-3 rounded-lg text-sm font-bold flex items-center justify-center gap-2 ${systemConfig?.maintenanceMode ? 'bg-emerald-600' : 'bg-rose-600'}`}>
                        {isToggling ? <RefreshCw className="animate-spin" size={16} /> : <Power size={16} />}
                        {systemConfig?.maintenanceMode ? 'Restaurar Acesso' : 'Bloquear Sistema'}
                    </button>

                    <button 
                        onClick={() => setShowResetModal(true)} 
                        className="w-full py-3 rounded-lg text-sm font-bold flex items-center justify-center gap-2 bg-red-900/50 text-red-400 border border-red-900 hover:bg-red-900 transition-colors"
                    >
                        <Trash2 size={16} />
                        Resetar Banco de Dados
                    </button>
                </div>

                {/* Global Beta Toggle */}
                <div className="bg-indigo-900/10 p-4 rounded-xl border border-indigo-500/20 mb-4">
                    <div className="flex items-center justify-between">
                         <span className="text-indigo-300 font-bold text-sm">Forçar Beta Global</span>
                         <button 
                            onClick={handleToggleGlobalBeta}
                            className={`w-10 h-5 rounded-full transition-colors relative shrink-0 ${
                                systemConfig?.forceGlobalBeta ? 'bg-indigo-500' : 'bg-slate-600'
                            }`}
                         >
                            <div className={`w-3 h-3 bg-white rounded-full absolute top-1 transition-transform shadow-md ${
                                systemConfig?.forceGlobalBeta ? 'left-6' : 'left-1'
                            }`} />
                         </button>
                    </div>
                    <p className="text--[10px] text-indigo-200 mt-2">
                        Ativa as funcionalidades experimentais para <strong>todos</strong> os usuários, ignorando a configuração individual.
                    </p>
                </div>

                 <button onClick={handleRestartAI} disabled={isRestarting} className="w-full bg-slate-800 border border-slate-600 text-slate-200 py-3 rounded-xl font-bold flex items-center justify-center gap-2">
                    <RefreshCw size={16} className={isRestarting ? "animate-spin" : ""} />
                    Reiniciar Monitor AI
                </button>
                
                <div className="mt-4 bg-slate-900/50 p-4 rounded-xl border border-slate-800">
                    <p className="text-slate-400 text-xs font-bold uppercase mb-2">Motor de Inteligência Ativo</p>
                    <div className="grid grid-cols-2 gap-2">
                        <button onClick={() => handleAISwitch('gemini')} className={`px-2 py-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1 transition-all ${aiConfig?.activeProvider === 'gemini' ? 'bg-blue-600 text-white ring-2 ring-blue-400' : 'bg-slate-800 text-slate-400 hover:bg-slate-700'}`}>
                            <Bot size={14} /> Gemini
                        </button>
                         <button onClick={() => handleAISwitch('openai')} className={`px-2 py-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1 transition-all ${aiConfig?.activeProvider === 'openai' ? 'bg-emerald-600 text-white ring-2 ring-emerald-400' : 'bg-slate-800 text-slate-400 hover:bg-slate-700'}`}>
                            <Zap size={14} /> ChatGPT
                        </button>
                    </div>
                </div>
            </div>
         </div>
      </div>
    </div>
  );
};

export default AdminPanel;
