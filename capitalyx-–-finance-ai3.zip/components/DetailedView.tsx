
import React, { useEffect, useState, useMemo } from 'react';
import { Transaction, TransactionType } from '../types';
import { generateCategoryInsights, CategoryAnalysisResult } from '../services/geminiService';
import { ArrowLeft, TrendingUp, TrendingDown, Target, Sparkles, Loader2, PieChart } from 'lucide-react';
import { motion } from 'framer-motion';
import { ResponsiveContainer, PieChart as RechartsPie, Pie, Cell, Tooltip, Legend } from 'recharts';

interface DetailedViewProps {
  type: 'balance' | 'income' | 'expense';
  transactions: Transaction[];
  onBack: () => void;
}

const formatCurrency = (value: number) => {
  return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
};

const DetailedView: React.FC<DetailedViewProps> = ({ type, transactions, onBack }) => {
  const [analysis, setAnalysis] = useState<CategoryAnalysisResult | null>(null);
  const [loading, setLoading] = useState(true);

  // Filter transactions based on type
  const filteredTransactions = useMemo(() => {
    if (type === 'balance') return transactions;
    const targetType = type === 'income' ? TransactionType.INCOME : TransactionType.EXPENSE;
    return transactions.filter(t => t.type === targetType);
  }, [transactions, type]);

  // Calculate Chart Data
  const chartData = useMemo(() => {
      const grouped: Record<string, number> = {};
      filteredTransactions.forEach(t => {
          // If balance view, stick to Income vs Expense
          if (type === 'balance') {
             const key = t.type === TransactionType.INCOME ? 'Receitas' : 'Despesas';
             grouped[key] = (grouped[key] || 0) + t.amount;
          } else {
             // If detail view, group by category
             grouped[t.category] = (grouped[t.category] || 0) + t.amount;
          }
      });
      return Object.entries(grouped).map(([name, value]) => ({ name, value }));
  }, [filteredTransactions, type]);

  const totalValue = filteredTransactions.reduce((acc, t) => {
      if (type === 'balance') return t.type === TransactionType.INCOME ? acc + t.amount : acc - t.amount;
      return acc + t.amount;
  }, 0);

  useEffect(() => {
    const fetchAI = async () => {
        setLoading(true);
        try {
            const result = await generateCategoryInsights(filteredTransactions, type);
            setAnalysis(result);
        } catch (error) {
            console.error(error);
        } finally {
            setLoading(false);
        }
    };
    
    // Pequeno delay para transição suave
    const timer = setTimeout(fetchAI, 500);
    return () => clearTimeout(timer);
  }, [type, filteredTransactions]);

  const getTitle = () => {
      switch(type) {
          case 'income': return 'Detalhamento de Receitas';
          case 'expense': return 'Detalhamento de Despesas';
          default: return 'Análise de Saldo & Fluxo';
      }
  };

  const getThemeColor = () => {
      switch(type) {
          case 'income': return 'text-emerald-400 border-emerald-500/30 bg-emerald-500/10';
          case 'expense': return 'text-rose-400 border-rose-500/30 bg-rose-500/10';
          default: return 'text-blue-400 border-blue-500/30 bg-blue-500/10';
      }
  };

  const COLORS = ['#3b82f6', '#10b981', '#ef4444', '#f59e0b', '#8b5cf6', '#ec4899'];

  // Helper to safely render AI text that might arrive as an object due to hallucination
  const safeRender = (content: any): string => {
      if (typeof content === 'string') return content;
      if (typeof content === 'number') return String(content);
      if (typeof content === 'object' && content !== null) {
          // If it's a summary object, try to grab a text field, otherwise generic message
          if (content.summary) return String(content.summary);
          if (content.text) return String(content.text);
          return "Detalhes em formato estruturado (ver logs)";
      }
      return "Indisponível";
  };

  return (
    <div className="space-y-6 pb-20">
        <div className="flex items-center gap-4">
            <button onClick={onBack} className="p-2 bg-slate-800 rounded-full hover:bg-slate-700 transition-colors">
                <ArrowLeft size={24} className="text-slate-200" />
            </button>
            <div>
                <h2 className="text-2xl font-bold text-white">{getTitle()}</h2>
                <p className="text-slate-400 text-sm">Organizado por Capitalyx AI</p>
            </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Left Column: AI Analysis */}
            <div className="lg:col-span-2 space-y-6">
                <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={`p-6 rounded-3xl border ${getThemeColor().split(' ')[1]} bg-surface relative overflow-hidden`}
                >
                    <div className="flex items-center gap-3 mb-4">
                        <Sparkles className={getThemeColor().split(' ')[0]} />
                        <h3 className="font-bold text-white text-lg">Inteligência Financeira</h3>
                    </div>

                    {loading ? (
                        <div className="flex flex-col items-center justify-center py-12 gap-3">
                            <Loader2 className="animate-spin text-slate-400" size={32} />
                            <p className="text-slate-500 animate-pulse">A IA está analisando cada transação...</p>
                        </div>
                    ) : analysis ? (
                        <div className="space-y-4">
                            <p className="text-slate-200 leading-relaxed text-lg">
                                {safeRender(analysis.analysis)}
                            </p>
                            
                            {Array.isArray(analysis.keyFactors) && analysis.keyFactors.length > 0 && (
                                <div className="bg-black/20 p-4 rounded-xl border border-white/5">
                                    <h4 className="text-sm font-bold text-slate-400 uppercase mb-2">Fatores Chave Identificados</h4>
                                    <ul className="grid grid-cols-1 md:grid-cols-2 gap-2">
                                        {analysis.keyFactors.map((factor, idx) => (
                                            <li key={idx} className="flex items-center gap-2 text-slate-300 text-sm">
                                                <div className={`w-1.5 h-1.5 rounded-full ${type === 'expense' ? 'bg-rose-500' : 'bg-emerald-500'}`} />
                                                {safeRender(factor)}
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                            )}

                            <div className={`p-4 rounded-xl border ${getThemeColor().split(' ')[1]} ${getThemeColor().split(' ')[2]}`}>
                                <h4 className={`font-bold text-sm uppercase mb-1 ${getThemeColor().split(' ')[0]}`}>Estratégia de Otimização</h4>
                                <p className="text-slate-200">
                                    {safeRender(analysis.optimizationStrategy)}
                                </p>
                            </div>
                        </div>
                    ) : (
                        <p className="text-slate-500">Falha ao carregar análise.</p>
                    )}
                </motion.div>

                {/* Transaction List Summary */}
                <div className="bg-surface rounded-3xl border border-slate-700 p-6">
                    <h3 className="font-bold text-white mb-4">Top Transações Recentes</h3>
                    <div className="space-y-3">
                        {filteredTransactions.slice(0, 5).map(t => (
                            <div key={t.id} className="flex justify-between items-center p-3 bg-slate-900/50 rounded-xl border border-slate-800">
                                <div>
                                    <p className="text-slate-200 font-medium">{t.description}</p>
                                    <p className="text-xs text-slate-500">{t.category} • {new Date(t.date).toLocaleDateString('pt-BR')}</p>
                                </div>
                                <span className={`font-bold ${t.type === 'income' ? 'text-emerald-400' : 'text-rose-400'}`}>
                                    {formatCurrency(t.amount)}
                                </span>
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            {/* Right Column: Chart & Stats */}
            <div className="space-y-6">
                <div className="bg-surface rounded-3xl border border-slate-700 p-6 flex flex-col items-center justify-center text-center">
                    <p className="text-slate-400 text-sm font-medium uppercase tracking-wider mb-2">Total Consolidado</p>
                    <span className={`text-4xl font-bold ${type === 'expense' ? 'text-rose-400' : type === 'income' ? 'text-emerald-400' : 'text-blue-400'}`}>
                        {formatCurrency(totalValue)}
                    </span>
                </div>

                <div className="bg-surface rounded-3xl border border-slate-700 p-6 h-[400px]">
                    <h3 className="font-bold text-white mb-4 flex items-center gap-2">
                        <PieChart size={18} className="text-slate-400" />
                        Distribuição
                    </h3>
                    <ResponsiveContainer width="100%" height="100%">
                        <RechartsPie>
                            <Pie
                                data={chartData}
                                innerRadius={60}
                                outerRadius={80}
                                paddingAngle={5}
                                dataKey="value"
                            >
                                {chartData.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                ))}
                            </Pie>
                            <Tooltip 
                                contentStyle={{ backgroundColor: '#1e293b', borderColor: '#475569', borderRadius: '8px', color: '#f1f5f9' }}
                                formatter={(value: number) => formatCurrency(value)}
                            />
                            <Legend verticalAlign="bottom" height={36} iconType="circle" />
                        </RechartsPie>
                    </ResponsiveContainer>
                </div>
            </div>
        </div>
    </div>
  );
};

export default DetailedView;
