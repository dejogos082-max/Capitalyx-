
import React, { useState, useMemo, useEffect } from 'react';
import { Transaction, RecurringTransaction, TransactionType } from '../types';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Calendar as CalendarIcon, 
  FastForward, 
  TrendingUp, 
  DollarSign, 
  ArrowRight, 
  Clock, 
  ChevronRight, 
  ChevronLeft,
  CalendarCheck,
  Plus
} from 'lucide-react';

// --- Helper Functions ---
const formatCurrency = (value: number) => {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL'
  }).format(value);
};

// --- WIDGET 1: FUTURE SIMULATOR (Receita Estimada) ---
interface FutureSimulatorProps {
  currentBalance: number;
  recurringTransactions: RecurringTransaction[];
  onUpdateStats?: (stats: any) => void; // NEW PROP
}

export const FutureSimulator: React.FC<FutureSimulatorProps> = ({ currentBalance, recurringTransactions, onUpdateStats }) => {
  const [monthsAhead, setMonthsAhead] = useState(1);

  // Trigger achievement if user slides to 12 months
  useEffect(() => {
      if (monthsAhead === 12 && onUpdateStats) {
          onUpdateStats({ hasSimulatedFuture: true });
      }
  }, [monthsAhead, onUpdateStats]);

  // Calculate monthly Net Flow from recurring items
  const monthlyFlow = useMemo(() => {
    return recurringTransactions.reduce((acc, t) => {
        if (!t.active) return acc;
        return t.type === TransactionType.INCOME ? acc + t.amount : acc - t.amount;
    }, 0);
  }, [recurringTransactions]);

  const projectedBalance = currentBalance + (monthlyFlow * monthsAhead);
  const projectedDate = new Date();
  projectedDate.setMonth(projectedDate.getMonth() + monthsAhead);

  return (
    <div className="bg-gradient-to-br from-indigo-900/40 to-slate-900 border border-indigo-500/30 p-6 rounded-3xl relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 p-4 opacity-10 pointer-events-none">
            <FastForward size={120} className="text-indigo-500" />
        </div>

        <div className="relative z-10">
            <div className="flex justify-between items-start mb-6">
                <div>
                    <h3 className="text-lg font-bold text-white flex items-center gap-2">
                        <TrendingUp className="text-indigo-400" size={20} />
                        Receita Estimada
                    </h3>
                    <p className="text-xs text-indigo-300/70 uppercase tracking-wider font-bold mt-1">Beta Feature</p>
                </div>
                <div className="bg-indigo-500/20 px-3 py-1 rounded-full border border-indigo-500/30 text-xs text-indigo-200">
                    IA Pattern Projection
                </div>
            </div>

            <div className="mb-8 flex flex-col items-center">
                <p className="text-slate-400 text-sm mb-1">Saldo Estimado em {projectedDate.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' })}</p>
                <motion.div 
                    key={monthsAhead}
                    initial={{ scale: 0.8, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    className="text-4xl md:text-5xl font-bold text-white drop-shadow-lg"
                >
                    {formatCurrency(projectedBalance)}
                </motion.div>
                <div className={`mt-2 text-sm font-medium ${monthlyFlow >= 0 ? 'bg-emerald-500/10 text-emerald-400' : 'bg-rose-500/10 text-rose-400'} px-3 py-1 rounded-lg border ${monthlyFlow >= 0 ? 'border-emerald-500/20' : 'border-rose-500/20'}`}>
                    Fluxo Recorrente: {monthlyFlow >= 0 ? '+' : ''}{formatCurrency(monthlyFlow)}/mês
                </div>
            </div>

            <div className="space-y-4">
                <div className="flex justify-between text-xs text-slate-400 font-bold uppercase tracking-widest">
                    <span>Hoje</span>
                    <span>+6 Meses</span>
                    <span>+1 Ano</span>
                </div>
                <input 
                    type="range" 
                    min="1" 
                    max="12" 
                    step="1" 
                    value={monthsAhead}
                    onChange={(e) => setMonthsAhead(parseInt(e.target.value))}
                    className="w-full h-3 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-indigo-500 hover:accent-indigo-400 transition-all"
                />
                <div className="text-center text-indigo-300 font-bold">
                    Avançando {monthsAhead} {monthsAhead === 1 ? 'mês' : 'meses'}
                </div>
            </div>
        </div>
    </div>
  );
};

// --- WIDGET 2: INTERACTIVE CALENDAR ---
interface InteractiveCalendarProps {
    recurringTransactions: RecurringTransaction[];
    onAddTransaction?: (date: string) => void;
    onUpdateStats?: (stats: any) => void; // NEW PROP
}

export const InteractiveCalendar: React.FC<InteractiveCalendarProps> = ({ recurringTransactions, onAddTransaction, onUpdateStats }) => {
    const [viewDate, setViewDate] = useState(new Date());
    const [selectedDate, setSelectedDate] = useState<number | null>(new Date().getDate());

    const daysInMonth = new Date(viewDate.getFullYear(), viewDate.getMonth() + 1, 0).getDate();
    const monthName = viewDate.toLocaleDateString('pt-BR', { month: 'long' });
    const capitalizedMonth = monthName.charAt(0).toUpperCase() + monthName.slice(1);
    const year = viewDate.getFullYear();

    const handleMonthChange = (increment: number) => {
        const newDate = new Date(viewDate);
        newDate.setMonth(newDate.getMonth() + increment);
        setViewDate(newDate);
        const newDaysInMonth = new Date(newDate.getFullYear(), newDate.getMonth() + 1, 0).getDate();
        if (selectedDate && selectedDate > newDaysInMonth) {
            setSelectedDate(newDaysInMonth);
        }
    };

    // Group transactions by day
    const eventsByDay = useMemo(() => {
        const map: Record<number, RecurringTransaction[]> = {};
        recurringTransactions.forEach(t => {
            if (!t.active) return;
            const day = t.dayOfMonth;
            if (!map[day]) map[day] = [];
            map[day].push(t);
        });
        return map;
    }, [recurringTransactions]);

    const selectedEvents = selectedDate ? eventsByDay[selectedDate] || [] : [];

    const handleAddClick = () => {
        if (onAddTransaction && selectedDate) {
            // Achievement Trigger
            if (onUpdateStats) onUpdateStats({ hasUsedCalendar: true });

            const month = (viewDate.getMonth() + 1).toString().padStart(2, '0');
            const day = selectedDate.toString().padStart(2, '0');
            const dateStr = `${year}-${month}-${day}`;
            onAddTransaction(dateStr);
        }
    };

    return (
        <div className="bg-surface border border-slate-700 p-6 rounded-3xl shadow-xl flex flex-col md:flex-row gap-6">
            
            {/* Calendar Grid Side */}
            <div className="flex-1">
                <div className="flex items-center justify-between mb-4 bg-slate-900/50 p-2 rounded-xl border border-slate-800">
                    <button 
                        onClick={() => handleMonthChange(-1)}
                        className="p-2 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-white transition-colors"
                    >
                        <ChevronLeft size={20} />
                    </button>
                    
                    <div className="flex flex-col items-center">
                        <h3 className="text-lg font-bold text-white flex items-center gap-2">
                            <CalendarCheck className="text-cyan-400" size={18} />
                            {capitalizedMonth}
                        </h3>
                        <span className="text-slate-500 text-xs font-bold">{year}</span>
                    </div>

                    <button 
                        onClick={() => handleMonthChange(1)}
                        className="p-2 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-white transition-colors"
                    >
                        <ChevronRight size={20} />
                    </button>
                </div>

                <div className="grid grid-cols-7 gap-2 text-center">
                    {['D','S','T','Q','Q','S','S'].map((d, i) => (
                        <div key={i} className="text-[10px] font-bold text-slate-500 uppercase py-2">{d}</div>
                    ))}
                    {Array.from({ length: daysInMonth }, (_, i) => i + 1).map(day => {
                        const hasEvents = !!eventsByDay[day];
                        const hasIncome = hasEvents && eventsByDay[day].some(t => t.type === TransactionType.INCOME);
                        const hasExpense = hasEvents && eventsByDay[day].some(t => t.type === TransactionType.EXPENSE);
                        const isSelected = selectedDate === day;
                        const isToday = day === new Date().getDate() && viewDate.getMonth() === new Date().getMonth() && viewDate.getFullYear() === new Date().getFullYear();

                        return (
                            <button
                                key={day}
                                onClick={() => setSelectedDate(day)}
                                className={`
                                    relative h-10 rounded-xl flex items-center justify-center text-sm font-medium transition-all
                                    ${isSelected ? 'bg-cyan-600 text-white shadow-lg shadow-cyan-500/30 scale-105 z-10' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'}
                                    ${isToday && !isSelected ? 'border-2 border-cyan-500/50 text-cyan-400' : ''}
                                `}
                            >
                                {day}
                                <div className="absolute bottom-1 flex gap-0.5">
                                    {hasIncome && <div className="w-1 h-1 rounded-full bg-emerald-400 shadow-[0_0_5px_rgba(52,211,153,0.8)]"></div>}
                                    {hasExpense && <div className="w-1 h-1 rounded-full bg-rose-400 shadow-[0_0_5px_rgba(251,113,133,0.8)]"></div>}
                                </div>
                            </button>
                        );
                    })}
                </div>
            </div>

            {/* Details Side */}
            <div className="w-full md:w-64 bg-slate-900/50 rounded-2xl border border-slate-700 p-4 flex flex-col">
                <div className="flex justify-between items-center mb-3 border-b border-slate-700 pb-2">
                    <h4 className="text-sm font-bold text-slate-300">
                        Dia {selectedDate} de {capitalizedMonth}
                    </h4>
                    <button 
                        onClick={handleAddClick}
                        className="bg-cyan-600 hover:bg-cyan-500 text-white p-1.5 rounded-lg transition-colors shadow-lg"
                        title="Adicionar Registro neste dia"
                    >
                        <Plus size={16} />
                    </button>
                </div>
                
                <div className="flex-1 overflow-y-auto space-y-2 max-h-[200px] custom-scrollbar min-h-[150px]">
                    {selectedEvents.length > 0 ? (
                        selectedEvents.map(t => (
                            <div key={t.id} className="bg-slate-800 p-3 rounded-xl border border-slate-700 flex justify-between items-center group hover:border-slate-600 transition-colors">
                                <div>
                                    <p className="text-xs font-bold text-slate-200">{t.description}</p>
                                    <p className="text-[10px] text-slate-500">{t.category}</p>
                                </div>
                                <span className={`text-xs font-bold ${t.type === TransactionType.INCOME ? 'text-emerald-400' : 'text-rose-400'}`}>
                                    {t.type === TransactionType.INCOME ? '+' : '-'}{formatCurrency(t.amount)}
                                </span>
                            </div>
                        ))
                    ) : (
                        <div className="h-full flex flex-col items-center justify-center text-slate-500 gap-2 opacity-60">
                            <CalendarIcon size={24} />
                            <p className="text-xs text-center">Nenhum evento<br/>recorrente</p>
                        </div>
                    )}
                </div>

                {selectedEvents.length > 0 && (
                    <div className="mt-3 pt-3 border-t border-slate-700 flex justify-between items-center text-xs font-bold text-slate-400">
                        <span>Total Recorrente:</span>
                        <span className="text-white">
                            {formatCurrency(selectedEvents.reduce((acc, t) => t.type === TransactionType.INCOME ? acc + t.amount : acc - t.amount, 0))}
                        </span>
                    </div>
                )}
                
                <button 
                    onClick={handleAddClick}
                    className="mt-3 w-full py-2 bg-slate-800 hover:bg-slate-700 border border-slate-600 border-dashed rounded-xl text-xs text-slate-400 hover:text-white transition-all flex items-center justify-center gap-2"
                >
                    <Plus size={12} />
                    Adicionar Registro
                </button>
            </div>
        </div>
    );
};
