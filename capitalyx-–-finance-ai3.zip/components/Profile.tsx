
import React, { useState, useRef, useEffect } from 'react';
import { UserProfile, Transaction } from '../types';
import { updateUserProfileData, auth } from '../services/firebase';
import { 
  User, Mail, Phone, Briefcase, Camera, 
  Save, Loader2, Upload, ShieldCheck, ImageIcon, Crown, LogOut
} from 'lucide-react';
import { motion } from 'framer-motion';

interface ProfileProps {
  user: UserProfile;
  transactions: Transaction[];
  onUpdateUser: (user: UserProfile) => void;
  onShowToast: (msg: string) => void;
  onLogout?: () => void;
}

const Profile: React.FC<ProfileProps> = ({ user, transactions, onUpdateUser, onShowToast, onLogout }) => {
  const [loading, setLoading] = useState(false);
  const [isReadOnly, setIsReadOnly] = useState(false);
  
  // State usando EXATAMENTE os IDs solicitados para identificação
  const [profileData, setProfileData] = useState({
    SetUserId: user.displayName || '',       // Nome de Usuário
    SetUserOcupation: user.jobTitle || '',   // Cargo/Ocupação
    SetUserPhone: user.phoneNumber || '',    // Telefone
    SetUserEmail: user.email || '',          // Email (Leitura)
    photoURL: user.photoURL || ''            // Mantido para funcionamento do avatar
  });

  const [imageMode, setImageMode] = useState<'upload' | 'url'>('upload');
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Verificação de segurança
  useEffect(() => {
     if (!auth.currentUser) {
         setIsReadOnly(true);
     } else {
         setIsReadOnly(false);
     }
  }, []);

  // Sincronização inicial com os dados do usuário
  useEffect(() => {
    setProfileData(prev => ({
        ...prev,
        SetUserId: user.displayName || '',
        SetUserOcupation: user.jobTitle || '',
        SetUserPhone: user.phoneNumber || '',
        SetUserEmail: user.email || '',
        photoURL: user.photoURL || ''
    }));
  }, [user]);

  // Handler genérico para os inputs baseados nos IDs
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (isReadOnly) return;
    const { id, value } = e.target;
    // O ID do input corresponde à chave no estado
    setProfileData(prev => ({ ...prev, [id]: value }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (isReadOnly) return;
    const file = e.target.files?.[0];
    if (file) {
        if (file.size > 1 * 1024 * 1024) {
            onShowToast("A imagem deve ter no máximo 1MB.");
            return;
        }
        const reader = new FileReader();
        reader.onloadend = () => {
            setProfileData(prev => ({ ...prev, photoURL: reader.result as string }));
        };
        reader.readAsDataURL(file);
    }
  };

  const handleSaveData = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isReadOnly) return;

    setLoading(true);
    try {
        // Mapeamento dos IDs solicitados para o esquema do banco de dados (UserProfile)
        const dataToSave: Partial<UserProfile> = {
            displayName: profileData.SetUserId,
            jobTitle: profileData.SetUserOcupation,
            phoneNumber: profileData.SetUserPhone,
            photoURL: profileData.photoURL
            // Email não é salvo aqui pois é gerido pelo Auth Provider
        };

        await updateUserProfileData(user.uid, dataToSave);
        
        // Atualiza estado local do App
        onUpdateUser({ ...user, ...dataToSave });
        onShowToast("Dados salvos com sucesso!");
    } catch (error: any) {
        console.error("Erro ao salvar perfil:", error);
        onShowToast("Erro ao salvar dados.");
    } finally {
        setLoading(false);
    }
  };

  // Stats para exibição
  const joinDate = user.createdAt ? new Date(user.createdAt).toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' }) : 'Recente';

  return (
    <div className="max-w-4xl mx-auto pb-10">
      
      {/* Banner Decorativo */}
      <div className="relative h-40 bg-gradient-to-r from-slate-900 to-indigo-950 rounded-b-3xl -mx-4 md:rounded-3xl md:mx-0 overflow-hidden mb-12 border-b border-slate-800 shadow-2xl">
         <div className="absolute inset-0 opacity-20">
            <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500 rounded-full blur-[100px]"></div>
            <div className="absolute bottom-0 left-0 w-64 h-64 bg-purple-500 rounded-full blur-[100px]"></div>
         </div>
      </div>

      <div className="px-4 relative z-10 -mt-20">
        <div className="bg-surface border border-slate-700 rounded-3xl p-8 shadow-2xl backdrop-blur-xl">
            
            {/* Cabeçalho do Perfil + Avatar */}
            <div className="flex flex-col md:flex-row items-center gap-8 mb-10 pb-8 border-b border-slate-700">
                <div className="relative group">
                    <div className="w-32 h-32 rounded-full border-4 border-slate-800 shadow-2xl overflow-hidden bg-slate-900 relative">
                        {profileData.photoURL ? (
                            <img src={profileData.photoURL} alt="Profile" className="w-full h-full object-cover" />
                        ) : (
                            <div className="w-full h-full flex items-center justify-center text-slate-600">
                                <User size={48} />
                            </div>
                        )}
                        
                        {/* Overlay de Upload */}
                        {!isReadOnly && (
                            <div 
                                className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center cursor-pointer"
                                onClick={() => fileInputRef.current?.click()}
                            >
                                <Camera className="text-white mb-1" size={24} />
                                <span className="text-[10px] text-white font-medium uppercase">Alterar</span>
                            </div>
                        )}
                    </div>
                    {/* Input Oculto para Imagem */}
                    <input 
                        type="file" 
                        ref={fileInputRef} 
                        onChange={handleFileChange} 
                        accept="image/*" 
                        className="hidden" 
                    />
                </div>

                <div className="flex-1 text-center md:text-left space-y-2">
                    <div className="flex flex-col md:flex-row items-center gap-3 justify-center md:justify-start">
                        <h2 className="text-3xl font-bold text-white">
                            {profileData.SetUserId || 'Usuário'}
                        </h2>
                        
                        {/* BADGES SECTION */}
                        <div className="flex items-center gap-2">
                            {user.isAdministrator && (
                                <span className="bg-rose-500/20 text-rose-400 text-xs px-3 py-1 rounded-full border border-rose-500/30 flex items-center gap-1 font-bold">
                                    <ShieldCheck size={12} /> ADMIN
                                </span>
                            )}
                            {user.badges?.includes('supporter') && (
                                <span className="bg-yellow-500/20 text-yellow-400 text-xs px-3 py-1 rounded-full border border-yellow-500/30 flex items-center gap-1 font-bold animate-pulse">
                                    <Crown size={12} /> APOIADOR
                                </span>
                            )}
                        </div>
                    </div>
                    
                    <p className="text-slate-400 text-lg">{profileData.SetUserOcupation || 'Defina sua ocupação'}</p>
                    <p className="text-xs text-slate-500 flex items-center justify-center md:justify-start gap-2">
                        <span>Membro desde {joinDate}</span>
                        <span className="w-1 h-1 bg-slate-600 rounded-full"></span>
                        <span>{transactions.length} Transações</span>
                    </p>
                </div>
            </div>

            {/* Formulário Principal */}
            <form onSubmit={handleSaveData} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    
                    {/* ID: SetUserId */}
                    <div className="space-y-2">
                        <label htmlFor="SetUserId" className="text-xs font-bold text-slate-400 uppercase tracking-wider ml-1">
                            Nome de Usuário
                        </label>
                        <div className="relative group">
                            <User className="absolute left-4 top-3.5 text-slate-500 group-focus-within:text-primary transition-colors" size={20} />
                            <input 
                                type="text"
                                id="SetUserId" 
                                value={profileData.SetUserId}
                                onChange={handleChange}
                                disabled={isReadOnly}
                                className="w-full bg-slate-900 border border-slate-700 rounded-xl py-3 pl-12 pr-4 text-white placeholder-slate-600 focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all"
                                placeholder="Digite seu nome completo"
                            />
                        </div>
                    </div>

                    {/* ID: SetUserOcupation */}
                    <div className="space-y-2">
                        <label htmlFor="SetUserOcupation" className="text-xs font-bold text-slate-400 uppercase tracking-wider ml-1">
                            Cargo / Ocupação
                        </label>
                        <div className="relative group">
                            <Briefcase className="absolute left-4 top-3.5 text-slate-500 group-focus-within:text-purple-400 transition-colors" size={20} />
                            <input 
                                type="text"
                                id="SetUserOcupation"
                                value={profileData.SetUserOcupation}
                                onChange={handleChange}
                                disabled={isReadOnly}
                                className="w-full bg-slate-900 border border-slate-700 rounded-xl py-3 pl-12 pr-4 text-white placeholder-slate-600 focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none transition-all"
                                placeholder="Ex: Desenvolvedor, Estudante..."
                            />
                        </div>
                    </div>

                    {/* ID: SetUserPhone */}
                    <div className="space-y-2">
                        <label htmlFor="SetUserPhone" className="text-xs font-bold text-slate-400 uppercase tracking-wider ml-1">
                            Número de Telefone
                        </label>
                        <div className="relative group">
                            <Phone className="absolute left-4 top-3.5 text-slate-500 group-focus-within:text-emerald-400 transition-colors" size={20} />
                            <input 
                                type="tel"
                                id="SetUserPhone"
                                value={profileData.SetUserPhone}
                                onChange={handleChange}
                                disabled={isReadOnly}
                                className="w-full bg-slate-900 border border-slate-700 rounded-xl py-3 pl-12 pr-4 text-white placeholder-slate-600 focus:ring-2 focus:ring-emerald-500 focus:border-transparent outline-none transition-all"
                                placeholder="(00) 00000-0000"
                            />
                        </div>
                    </div>

                    {/* ID: SetUserEmail (Read Only) */}
                    <div className="space-y-2">
                        <label htmlFor="SetUserEmail" className="text-xs font-bold text-slate-400 uppercase tracking-wider ml-1 flex justify-between">
                            E-mail do Usuário
                            <span className="text-[10px] text-slate-600 bg-slate-800 px-2 rounded">Somente Leitura</span>
                        </label>
                        <div className="relative">
                            <Mail className="absolute left-4 top-3.5 text-slate-500" size={20} />
                            <input 
                                type="email"
                                id="SetUserEmail"
                                value={profileData.SetUserEmail}
                                disabled={true}
                                className="w-full bg-slate-800/50 border border-slate-700 rounded-xl py-3 pl-12 pr-4 text-slate-400 cursor-not-allowed"
                            />
                        </div>
                    </div>

                </div>

                {!isReadOnly && (
                    <div className="pt-8 flex flex-col md:flex-row items-center justify-between border-t border-slate-700 mt-8 gap-4">
                        {onLogout && (
                            <button
                                type="button"
                                onClick={onLogout}
                                className="text-rose-400 hover:text-rose-300 font-medium flex items-center gap-2 px-4 py-2 rounded-xl hover:bg-rose-500/10 transition-colors"
                            >
                                <LogOut size={20} />
                                Sair da Conta
                            </button>
                        )}
                        <button 
                            type="submit" 
                            disabled={loading}
                            className="bg-primary hover:bg-blue-600 text-white font-bold py-4 px-10 rounded-2xl shadow-lg shadow-primary/20 transition-all active:scale-95 flex items-center gap-3 w-full md:w-auto justify-center"
                        >
                            {loading ? (
                                <Loader2 className="animate-spin" size={22} />
                            ) : (
                                <Save size={22} />
                            )}
                            Salvar Dados
                        </button>
                    </div>
                )}
            </form>
        </div>
      </div>
    </div>
  );
};

export default Profile;
