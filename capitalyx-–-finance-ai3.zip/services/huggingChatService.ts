
import { AIAnalysisResult } from "../types";

// --- HuggingChat Integration Module ---
// Namespace: HuggingChatClient

// --- Authentication Constants ---
// Note: These tokens are often rate-limited public tokens. 
// For production, use process.env.HF_TOKEN
const HF_TOKEN_GENERAL = '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';

// --- Types ---
export interface HuggingQueryPayload {
  inputs: string;
  parameters?: {
    max_new_tokens?: number;
    temperature?: number;
    top_p?: number;
    return_full_text?: boolean;
    [key: string]: any;
  };
  options?: {
    use_cache?: boolean;
    wait_for_model?: boolean;
  };
}

// Helper para limpar JSON
const cleanJsonString = (rawString: string): string => {
  let cleaned = rawString.trim();
  
  // Tenta encontrar o primeiro { e o último }
  const firstBrace = cleaned.indexOf('{');
  const lastBrace = cleaned.lastIndexOf('}');
  
  if (firstBrace !== -1 && lastBrace !== -1) {
      cleaned = cleaned.substring(firstBrace, lastBrace + 1);
  }

  return cleaned;
};

// --- Client Implementation ---
export const HuggingChatClient = {
  
  baseUrl: "https://api-inference.huggingface.co/models/",
  // Usando Mistral 7B pois Llama 3 é gated e causa erros de CORS/403 sem token pessoal validado
  defaultModel: "mistralai/Mistral-7B-Instruct-v0.3",

  /**
   * Sends a query to the Hugging Face Inference API.
   */
  sendQuery: async (data: HuggingQueryPayload, model: string = "mistralai/Mistral-7B-Instruct-v0.3"): Promise<any> => {
    const url = `https://api-inference.huggingface.co/models/${model}`;
    
    console.debug(`[HuggingChatClient] Preparing to send query to ${model}`);

    try {
      const response = await fetch(url, {
        headers: {
          Authorization: `Bearer ${HF_TOKEN_GENERAL}`,
          "Content-Type": "application/json",
        },
        method: "POST",
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        const errorDetails = await response.text();
        console.error(`[HuggingChatClient] API Error: ${response.status}`, errorDetails);
        throw new Error(`Hugging Face API Error: ${response.status} - ${response.statusText}`);
      }

      const result = await response.json();
      return result;

    } catch (error) {
      console.error("[HuggingChatClient] Network or Execution Error:", error);
      throw error;
    }
  },

  /**
   * Gera Análise Financeira via Hugging Face
   */
  generateAnalysis: async (prompt: string): Promise<AIAnalysisResult> => {
      // Prompt ajustado para Mistral Instruct
      const enhancedPrompt = `<s>[INST] You are a financial analyst API. You MUST output ONLY valid JSON. No markdown, no conversation.
Schema:
{
  "summary": "string",
  "savingsTip": "string",
  "alert": "string or null",
  "prediction": "string",
  "cashFlowTip": "string",
  "suggestedGoals": [{"title": "string", "targetAmount": number, "deadline": "YYYY-MM-DD"}]
}

DATA:
${prompt}
[/INST]`;

      const result = await HuggingChatClient.sendQuery({
          inputs: enhancedPrompt,
          parameters: {
              max_new_tokens: 1200,
              temperature: 0.1, // Baixa temperatura para garantir JSON
              return_full_text: false
          },
          options: { wait_for_model: true }
      });

      // A API retorna um array, geralmente result[0].generated_text
      let text = "";
      if (Array.isArray(result) && result.length > 0) {
          text = result[0].generated_text;
      } else if (typeof result === 'object' && result.generated_text) {
          text = result.generated_text;
      } else {
          // Fallback para string direta se a API mudar
          text = JSON.stringify(result);
      }

      const cleaned = cleanJsonString(text);
      try {
          const json = JSON.parse(cleaned) as AIAnalysisResult;
          return { ...json, analyzedAt: Date.now() };
      } catch (e) {
          console.error("HF Parse Error. Raw:", text);
          throw new Error("Falha ao parsear JSON do Hugging Face. Resposta inválida.");
      }
  },

  _config: {
    tokens: {
      general: HF_TOKEN_GENERAL
    }
  }
};
