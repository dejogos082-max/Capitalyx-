
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { Transaction, AIAnalysisResult, FinancialGoal, TransactionType, AIProvider, FinancialScoreResult } from "../types";
import { getAIConfig } from "./firebase";
import { OpenAIConfig } from "./openAIService";

const cleanJsonString = (rawString: string): string => {
  let cleaned = rawString.trim();
  const jsonBlockRegex = /```(?:json)?\s*([\s\S]*?)\s*```/i;
  const match = cleaned.match(jsonBlockRegex);
  if (match && match[1]) { cleaned = match[1].trim(); }
  if (!match) {
      cleaned = cleaned.replace(/^```json/, "").replace(/```$/, "").trim();
  }
  return cleaned;
};

/**
 * Orquestrador Central de IA
 */
const callActiveAIProvider = async (prompt: string, provider: AIProvider, jsonMode: boolean = true): Promise<{ text: string, usedProvider: AIProvider }> => {
    let activeProvider = provider;

    if (activeProvider === 'openai') {
        try {
            const oaResult = await OpenAIConfig.execute([{ role: 'user', content: prompt }]);
            return { text: oaResult.choices?.[0]?.message?.content || "", usedProvider: 'openai' };
        } catch (e: any) {
            console.warn("[Orchestrator] OpenAI falhou (Quota/Erro), tentando fallback Gemini...", e.message);
            activeProvider = 'gemini'; // Ativa fallback para esta chamada
        }
    }

    // Default ou Fallback para Gemini
    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: prompt,
            config: jsonMode ? { responseMimeType: "application/json" } : {}
        });
        return { text: response.text || "", usedProvider: 'gemini' };
    } catch (e: any) {
        console.error("[Orchestrator] Erro fatal em ambos os provedores.");
        throw e;
    }
};

export const generateFinancialInsights = async (
    transactions: Transaction[], 
    goals: FinancialGoal[] = [], 
    recurringTransactions: any[] = [], 
    customCategories: any[] = []
): Promise<AIAnalysisResult> => {
  const aiConfig = await getAIConfig();
  const provider = aiConfig.activeProvider || 'gemini';

  const simpleTx = transactions.slice(0, 50).map(t => ({ d: t.date, v: t.amount, t: t.type, c: t.category }));
  const prompt = `Analise: ${JSON.stringify({tx: simpleTx, goals, recurring: recurringTransactions})}. 
  Responda em PT-BR JSON: {
    "summary": "texto",
    "savingsTip": "texto",
    "alert": "texto ou null",
    "prediction": "texto",
    "cashFlowTip": "texto",
    "investmentTip": "texto",
    "spendingHabit": "texto",
    "suggestedGoals": [{"title": "texto", "targetAmount": number, "deadline": "YYYY-MM-DD"}],
    "futureProjections": [{"month": "texto", "projectedBalance": number, "note": "texto"}]
  }`;
  
  try {
      // Prioriza a lógica específica do OpenAI se selecionado
      if (provider === 'openai') {
          try {
            return await OpenAIConfig.generateAnalysis(prompt);
          } catch (e) {
            console.warn("[Insights] OpenAI Error, fallback to Gemini.");
            // Falha silenciosa para cair no bloco Gemini abaixo
          }
      }
      
      // Lógica Gemini (Default ou Fallback)
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
          model: 'gemini-3-flash-preview',
          contents: prompt,
          config: { responseMimeType: "application/json" }
      });
      
      const text = response.text || "{}";
      const json = JSON.parse(cleanJsonString(text));
      return { ...json, providerUsed: 'gemini', analyzedAt: Date.now() };

  } catch (error: any) {
      console.error("Erro na análise global:", error);
      return {
          summary: "A IA está com instabilidade temporária.",
          savingsTip: "Verifique suas configurações de API no painel Admin.",
          alert: "Motor de IA Offline",
          prediction: "Aguardando estabilidade",
          cashFlowTip: "Revise seus gastos fixos manualmente.",
          suggestedGoals: [],
          analyzedAt: Date.now()
      };
  }
};

export const generateFinancialScore = async (transactions: Transaction[]): Promise<FinancialScoreResult> => {
    const aiConfig = await getAIConfig();
    const provider = aiConfig.activeProvider || 'gemini';
    
    if (transactions.length < 2) return { score: 500, rating: 'Regular', analysis: "Dados insuficientes.", factors: [], providerUsed: provider };
    
    const simpleTx = transactions.slice(0, 40).map(t => ({ v: t.amount, t: t.type, c: t.category }));
    const prompt = `Gere score financeiro (0-1000). Dados: ${JSON.stringify(simpleTx)}. 
    JSON: {"score": number, "rating": "Regular/Excelente", "analysis": "texto", "factors": [{"name": "texto", "impact": "positive/negative"}]}`;
    
    try {
        const { text, usedProvider } = await callActiveAIProvider(prompt, provider);
        return { ...JSON.parse(cleanJsonString(text)), providerUsed: usedProvider };
    } catch (e) {
        return { score: 0, rating: 'Regular', analysis: "Erro de comunicação.", factors: [], providerUsed: provider };
    }
};

export const generateAIOnlyGoals = async (transactions: Transaction[]): Promise<any[]> => {
    try {
        const aiConfig = await getAIConfig();
        const provider = aiConfig.activeProvider || 'gemini';
        const simpleTx = transactions.slice(0, 30).map(t => ({ v: t.amount, c: t.category, d: t.date }));
        const prompt = `Gere metas baseadas em: ${JSON.stringify(simpleTx)}. JSON: {"goals": [{"title": "string", "targetAmount": number, "deadline": "YYYY-MM-DD"}]}`;
        const { text } = await callActiveAIProvider(prompt, provider);
        return JSON.parse(cleanJsonString(text)).goals || [];
    } catch (e) { return []; }
};

export interface CategoryAnalysisResult {
    analysis: string;
    keyFactors: string[];
    optimizationStrategy: string;
}

export const generateCategoryInsights = async (transactions: Transaction[], viewType: string): Promise<CategoryAnalysisResult> => {
    try {
        const aiConfig = await getAIConfig();
        const provider = aiConfig.activeProvider || 'gemini';
        const prompt = `Analise transações de ${viewType}: ${JSON.stringify(transactions.slice(0, 20))}. JSON: {"analysis": "texto", "keyFactors": ["string"], "optimizationStrategy": "texto"}`;
        const { text } = await callActiveAIProvider(prompt, provider);
        return JSON.parse(cleanJsonString(text)) as CategoryAnalysisResult;
    } catch (e) {
        return { analysis: "Falha na análise.", keyFactors: [], optimizationStrategy: "Tente novamente." };
    }
};

export const generateAchievementIcon = async (description: string): Promise<string | null> => {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-image',
            contents: { parts: [{ text: `Flat icon, financial theme, minimalist, background slate-900: ${description}` }] },
            config: { imageConfig: { aspectRatio: "1:1" } }
        });
        if (response.candidates?.[0]?.content?.parts) {
            for (const part of response.candidates[0].content.parts) {
                if (part.inlineData) return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
            }
        }
        return null;
    } catch (e) { return null; }
};
