
import { AuthError, User, sendEmailVerification } from "firebase/auth";
import { auth } from "./firebase";

// --- Constantes ---
const VERIFICATION_COOLDOWN_MS = 60 * 1000; // 60 segundos padrão
const BLOCK_COOLDOWN_MS = 5 * 60 * 1000; // 5 minutos se for bloqueado
const STORAGE_KEY_LAST_SENT = 'cpt_last_verify_sent';

// --- Tradutor de Erros do Firebase ---
export const mapAuthErrorToMessage = (error: any): string => {
  const code = error.code || '';
  const msg = error.message || '';

  // Log apenas se não for um erro comum de validação, para debug
  if (!code.startsWith('auth/')) {
      console.warn("Auth Error Intercepted:", code, msg);
  }

  switch (code) {
    case 'auth/unauthorized-domain':
      return 'Este domínio não está autorizado no Firebase. Adicione o URL atual nas configurações de "Domínios Autorizados" no Console do Firebase.';
    
    case 'auth/invalid-credential':
    case 'auth/wrong-password':
    case 'auth/user-not-found':
      return 'E-mail ou senha incorretos. Verifique seus dados.';
    
    case 'auth/too-many-requests':
      return 'Muitas tentativas. O sistema bloqueou temporariamente o envio. Aguarde alguns minutos.';
    
    case 'auth/email-already-in-use':
      return 'Este e-mail já está cadastrado. Faça login ou use a recuperação de senha.';
    
    case 'auth/weak-password':
      return 'A senha é muito fraca. Use pelo menos 6 caracteres.';
    
    case 'auth/invalid-email':
      return 'O formato do e-mail é inválido.';
    
    case 'auth/network-request-failed':
      return 'Erro de conexão. Verifique sua internet.';
      
    case 'auth/popup-closed-by-user':
      return 'O login social foi cancelado antes de concluir.';

    case 'auth/requires-recent-login':
      return 'Por segurança, faça logout e login novamente antes de realizar esta ação.';

    case 'auth/credential-already-in-use':
      return 'Esta conta social já está associada a outro usuário.';

    default:
      if (msg.includes('invalid-credential')) return 'Credenciais inválidas.';
      if (msg.includes('email-already-in-use')) return 'Este e-mail já está cadastrado.';
      if (msg.includes('unauthorized-domain')) return 'Domínio não autorizado no Firebase Console.';
      return 'Ocorreu um erro na autenticação. Tente novamente.';
  }
};

// --- Sistema Otimizado de Verificação de E-mail ---
export const sendOptimizedVerificationEmail = async (user: User): Promise<{ success: boolean; message: string; remainingTime?: number }> => {
  if (!user) return { success: false, message: "Usuário não identificado." };
  if (user.emailVerified) return { success: true, message: "E-mail já verificado!" };

  const now = Date.now();
  const lastSentStr = localStorage.getItem(STORAGE_KEY_LAST_SENT);
  const lastSent = lastSentStr ? parseInt(lastSentStr, 10) : 0;

  // Verifica Cooldown Local antes de chamar o Firebase
  if (now - lastSent < VERIFICATION_COOLDOWN_MS) {
    const remainingSeconds = Math.ceil((VERIFICATION_COOLDOWN_MS - (now - lastSent)) / 1000);
    return { 
      success: false, 
      message: `Aguarde ${remainingSeconds}s para reenviar o e-mail.`,
      remainingTime: remainingSeconds
    };
  }

  try {
    console.log("Tentando enviar e-mail de verificação para:", user.email);
    
    // Força o reload do usuário para garantir que o token está fresco
    await user.reload();
    
    await sendEmailVerification(user);
    
    // Atualiza timestamp com sucesso
    localStorage.setItem(STORAGE_KEY_LAST_SENT, now.toString());
    
    return { 
      success: true, 
      message: `Link de verificação enviado para ${user.email}. Verifique também sua caixa de SPAM.` 
    };

  } catch (error: any) {
    console.error("Erro no envio de e-mail:", error);
    
    if (error.code === 'auth/too-many-requests') {
        const penaltyTime = now + BLOCK_COOLDOWN_MS - VERIFICATION_COOLDOWN_MS;
        localStorage.setItem(STORAGE_KEY_LAST_SENT, penaltyTime.toString());
        
        return { 
            success: false, 
            message: "Muitas tentativas. Aguarde 5 minutos antes de tentar novamente.",
            remainingTime: 300 
        };
    }

    return { success: false, message: mapAuthErrorToMessage(error) };
  }
};

export const getVerificationCooldownRemaining = (): number => {
    const now = Date.now();
    const lastSentStr = localStorage.getItem(STORAGE_KEY_LAST_SENT);
    if (!lastSentStr) return 0;
    
    const lastSent = parseInt(lastSentStr, 10);
    const diff = now - lastSent;
    
    if (diff < VERIFICATION_COOLDOWN_MS) {
        return Math.ceil((VERIFICATION_COOLDOWN_MS - diff) / 1000);
    }
    
    return 0;
};
