
import { GoogleGenAI } from "@google/genai";
import { logIntegrityCheck, applySystemPatch, db, getAIConfig } from "./firebase";
import { ref, update } from "firebase/database";
import { OpenAIConfig } from "./openAIService";

const gatherSystemMetrics = () => {
    const mem = (performance as any).memory;
    return {
        timestamp: new Date().toISOString(),
        userAgent: navigator.userAgent,
        online: navigator.onLine,
        memoryUsage: mem ? Math.round(mem.usedJSHeapSize / 1024 / 1024) + 'MB' : 'N/A',
        loadTime: Math.round(performance.now()) + 'ms'
    };
};

export const executeAIAutoFix = async (trigger: string) => {
    if (!db) return;
    try {
        await update(ref(db, 'system_settings/config'), { maintenanceMode: false, lastUpdated: Date.now() });
        await update(ref(db, 'system_settings/integrity_config'), { status: 'idle', isPaused: false, checkCount: 0 });
        await applySystemPatch(`v3.1.${Date.now().toString().slice(-4)}`, "AI_CORE_REPAIR");
    } catch (error) { console.error("Falha no Auto-Fix:", error); }
};

export const runAIIntegrityCheck = async () => {
    const aiConfig = await getAIConfig();
    const activeProvider = aiConfig.activeProvider || 'gemini';
    const metrics = gatherSystemMetrics();

    await logIntegrityCheck({ 
        timestamp: Date.now(), 
        step: 'INIT', 
        status: 'ok', 
        details: `Varredura iniciada via engine: ${activeProvider.toUpperCase()}` 
    });

    try {
        let textResponse = "";
        const prompt = `Aja como o 'Capitalyx Sentinel'. Analise estas métricas: ${JSON.stringify(metrics)}. 
        Retorne JSON: {"status": "HEALTHY" | "ERROR", "details": "string"}. 
        Se Online for true e memória < 1GB, status é HEALTHY.`;

        if (activeProvider === 'openai') {
            const result = await OpenAIConfig.execute([
                { role: 'system', content: 'Você é um monitor de integridade de sistemas.' },
                { role: 'user', content: prompt }
            ]);
            const content = result.choices?.[0]?.message?.content || "";
            try {
                const parsed = JSON.parse(content);
                textResponse = `[OPENAI] ${parsed.status}: ${parsed.details}`;
            } catch {
                textResponse = content;
            }
        } else {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const response = await ai.models.generateContent({ 
                model: 'gemini-3-flash-preview', 
                contents: prompt,
                config: { responseMimeType: "application/json" }
            });
            const content = response.text || "";
            try {
                const parsed = JSON.parse(content);
                textResponse = `[GEMINI] ${parsed.status}: ${parsed.details}`;
            } catch {
                textResponse = content;
            }
        }

        const isError = textResponse.toUpperCase().includes('ERROR') || textResponse.toUpperCase().includes('CRITICAL');

        await logIntegrityCheck({ 
            timestamp: Date.now(), 
            step: 'AI_ANALYSIS', 
            status: isError ? 'error' : 'ok', 
            details: textResponse,
            provider: activeProvider 
        });

    } catch (e: any) {
        console.error("Monitor AI falhou:", e);
        await logIntegrityCheck({ 
            timestamp: Date.now(), 
            step: 'FATAL_ERROR', 
            status: 'error', 
            details: `Falha técnica: ${e.message}`,
            provider: activeProvider
        });
    }
};
