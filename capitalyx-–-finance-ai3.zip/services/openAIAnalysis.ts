
// --- OpenAI Analysis Logic ---
// Handles formatting and parsing specific to OpenAI for AI Monitor

import { OpenAIConfig, OpenAIMessage } from "./openAIService";

interface OpenAIAnalysisResponse {
    status: 'ok' | 'warning' | 'error';
    summary: string;
}

export const runOpenAISystemAnalysis = async (metrics: any): Promise<OpenAIAnalysisResponse> => {
    
    const messages: OpenAIMessage[] = [
        {
            role: "system",
            content: "Você é o 'Capitalyx Sentinel' (OpenAI Engine). Analise JSON de métricas do servidor. Responda JSON: { \"status\": \"ok|warning|error\", \"summary\": \"texto curto\" }."
        },
        {
            role: "user",
            content: `Analise: ${JSON.stringify(metrics)}. Regras: Offline=error, Memoria>500MB=warning. Caso contrário ok.`
        }
    ];

    try {
        const result = await OpenAIConfig.execute(messages);
        const rawContent = result.choices?.[0]?.message?.content || "";
        
        const parsed = JSON.parse(rawContent);
        
        let status: 'ok' | 'warning' | 'error' = 'ok';
        if (parsed.status === 'error' || parsed.status === 'critical') status = 'error';
        else if (parsed.status === 'warning') status = 'warning';
        
        return { 
            status: status, 
            summary: parsed.summary || "Análise OpenAI concluída." 
        };

    } catch (error) {
        console.error("[OpenAIAnalysis] Falha na análise:", error);
        throw error;
    }
};
