
import { initializeApp, getApp, getApps, FirebaseApp } from "firebase/app";
import { 
  getAuth, 
  GoogleAuthProvider, 
  GithubAuthProvider, 
  signInWithPopup, 
  signOut, 
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  sendPasswordResetEmail,
  sendEmailVerification,
  signInWithPhoneNumber,
  RecaptchaVerifier,
  User,
  verifyBeforeUpdateEmail,
  updateProfile,
  Auth,
  UserCredential,
  ConfirmationResult,
  setPersistence,
  browserLocalPersistence
} from "firebase/auth";
import { 
  getDatabase, 
  ref, 
  push, 
  onValue, 
  remove, 
  set, 
  off, 
  update, 
  get, 
  Database,
  DataSnapshot,
  query,
  orderByChild,
  equalTo
} from "firebase/database";
import { Transaction, UserStats, FinancialGoal, UserProfile, SystemConfig, IntegrityLog, IntegrityState, AIUsageStats, AIConfig, AIProvider, RecurringTransaction, Achievement } from "../types";

// --- Configuration ---
const firebaseConfig = {
  apiKey: "AIzaSyCdAoxxkk9asrhoXJB-iySix-gG14B6qlI",
  authDomain: "gestaoapp-baac6.firebaseapp.com",
  databaseURL: "https://gestaoapp-baac6-default-rtdb.firebaseio.com",
  projectId: "gestaoapp-baac6",
  storageBucket: "gestaoapp-baac6.firebasestorage.app",
  messagingSenderId: "965601428152",
  appId: "1:965601428152:web:3c25d32c111e03c6f32a4d",
  measurementId: "G-2BXS6KL8JK"
};

// --- Singleton Instances ---
const getSafeApp = () => {
    try {
        return getApp();
    } catch {
        return initializeApp(firebaseConfig);
    }
};

const app = getSafeApp();
export const auth = getAuth(app);
export const db = getDatabase(app);

setPersistence(auth, browserLocalPersistence).catch(e => console.warn("Firebase persistence disabled:", e));
auth.languageCode = 'pt';

const googleProvider = new GoogleAuthProvider();
const githubProvider = new GithubAuthProvider();

const ensureAuth = (): void => {
    if (!auth) throw new Error("Serviço de Autenticação indisponível.");
};
const ensureDb = (): void => {
    if (!db) throw new Error("Banco de Dados indisponível.");
};

const cleanData = (obj: any) => {
    if (!obj) return {};
    return Object.fromEntries(
        Object.entries(obj).filter(([_, v]) => v !== undefined && v !== null)
    );
};

// --- Authentication Services ---
export const loginWithGoogle = async (): Promise<void> => {
  ensureAuth();
  await signInWithPopup(auth, googleProvider);
};

export const loginWithGithub = async (): Promise<void> => {
  ensureAuth();
  await signInWithPopup(auth, githubProvider);
};

export const registerWithEmail = async (
    email: string, 
    pass: string, 
    profileData: { jobTitle?: string, displayName?: string, phoneNumber?: string }
): Promise<User> => {
  ensureAuth();
  const userCredential: UserCredential = await createUserWithEmailAndPassword(auth, email, pass);
  const user = userCredential.user;

  if (profileData.displayName) {
      try { await updateProfile(user, { displayName: profileData.displayName }); } catch (e) {}
  }
  
  if (db) {
      const profileRef = ref(db, `users/${user.uid}/profile`);
      await update(profileRef, {
          email: user.email,
          createdAt: Date.now(),
          isAdministrator: false,
          ...profileData
      });
  }

  try { await sendEmailVerification(user); } catch(e) {}
  return user;
};

export const loginWithEmail = async (email: string, pass: string): Promise<UserCredential> => {
  ensureAuth();
  return await signInWithEmailAndPassword(auth, email, pass);
};

export const resetPassword = async (email: string): Promise<void> => {
  ensureAuth();
  return await sendPasswordResetEmail(auth, email);
};

export const logout = async (): Promise<void> => {
    if(auth) await signOut(auth);
};

// --- Login Code System ---
export interface LoginCodeData {
  code: string;
  expiresAt: number;
  createdAt: number;
}

export const generateLoginCode = async (uid: string): Promise<LoginCodeData> => {
  ensureDb();
  const userCodeRef = ref(db, `users/${uid}/security/loginCode`);
  const snapshot = await get(userCodeRef);
  const now = Date.now();

  if (snapshot.exists()) {
    const existingData = snapshot.val();
    if (existingData.createdAt && (now - existingData.createdAt < 24 * 60 * 60 * 1000)) {
        throw new Error("COOLDOWN");
    }
    if (existingData.code) {
        await remove(ref(db, `login_codes/${existingData.code}`));
    }
  }

  const code = Math.floor(100000 + Math.random() * 900000).toString();
  const expiresAt = now + (7 * 24 * 60 * 60 * 1000);
  
  await set(ref(db, `login_codes/${code}`), { uid, expiresAt });
  const codeData: LoginCodeData = { code, expiresAt, createdAt: now };
  await set(userCodeRef, codeData);

  return codeData;
};

export const getStoredLoginCode = async (uid: string): Promise<LoginCodeData | null> => {
  ensureDb();
  const snapshot = await get(ref(db, `users/${uid}/security/loginCode`));
  if (snapshot.exists()) {
    const data = snapshot.val();
    if (Date.now() > data.expiresAt) {
        await remove(ref(db, `login_codes/${data.code}`));
        await remove(ref(db, `users/${uid}/security/loginCode`));
        return null;
    }
    return data;
  }
  return null;
};

export const verifyLoginCode = async (code: string): Promise<{ uid: string, expiresAt: number } | null> => {
  ensureDb();
  const snapshot = await get(ref(db, `login_codes/${code}`));
  if (snapshot.exists()) {
    const data = snapshot.val();
    if (Date.now() < data.expiresAt) return data;
    await remove(ref(db, `login_codes/${code}`));
  }
  return null;
};

export const setupRecaptcha = (containerId: string): RecaptchaVerifier => {
    ensureAuth();
    return new RecaptchaVerifier(auth, containerId, {
        'size': 'invisible'
    });
};

export const loginWithPhone = async (phoneNumber: string, appVerifier: RecaptchaVerifier): Promise<ConfirmationResult> => {
    ensureAuth();
    return await signInWithPhoneNumber(auth, phoneNumber, appVerifier);
};

export const updateUserEmail = async (user: User, newEmail: string): Promise<void> => {
    ensureAuth();
    return await verifyBeforeUpdateEmail(user, newEmail);
};

// --- User Profile Management ---
export const saveUserProfileToDB = async (user: User): Promise<void> => {
    if (!db) return;
    try {
        const profileRef = ref(db, `users/${user.uid}/profile`);
        const snapshot = await get(profileRef);
        const existing = snapshot.exists() ? snapshot.val() : {};

        await update(profileRef, {
            ...existing,
            email: user.email,
            emailVerified: user.emailVerified,
            lastLogin: Date.now(),
            displayName: user.displayName || existing.displayName || 'Usuário',
            photoURL: user.photoURL || existing.photoURL || null
        });
    } catch (e) {
        console.warn("Erro ao salvar perfil no DB:", e);
    }
};

export const grantAdminPrivileges = async (uid: string): Promise<void> => {
  ensureDb();
  const profileRef = ref(db, `users/${uid}/profile`);
  await update(profileRef, { isAdministrator: true });
};

export const validateAdminIntegrity = async (uid: string): Promise<boolean> => {
  if (!db || !uid) return false;
  try {
      const snapshot = await get(ref(db, `users/${uid}/profile/isAdministrator`));
      if (!snapshot.exists()) return false;
      return snapshot.val() === true;
  } catch (e: any) {
      console.warn("Admin Integrity Check deferred:", e.message);
      return true; 
  }
};

export const updateUserProfileData = async (uid: string, data: Partial<UserProfile>): Promise<void> => {
    ensureDb();
    const profileRef = ref(db, `users/${uid}/profile`);
    await update(profileRef, data);
};

export const getUserProfileData = async (uid: string): Promise<UserProfile> => {
    const snapshot = await get(ref(db, `users/${uid}/profile`));
    return snapshot.exists() ? snapshot.val() : { uid };
};

export const subscribeToUserProfile = (uid: string, onUpdate: (data: UserProfile | null) => void) => {
  if (!db || !uid) return () => {};
  const profileRef = ref(db, `users/${uid}/profile`);
  const handleValue = (snapshot: DataSnapshot) => onUpdate(snapshot.val());
  onValue(profileRef, handleValue);
  return () => off(profileRef, 'value', handleValue);
};

// --- ACHIEVEMENTS ---
export const addAchievement = async (achievement: Omit<Achievement, 'id'>) => {
    ensureDb();
    const newRef = push(ref(db, 'system_settings/achievements'));
    const sanitized = cleanData(achievement);
    await set(newRef, { ...sanitized, id: newRef.key });
};

export const deleteAchievement = async (id: string) => {
    ensureDb();
    await remove(ref(db, `system_settings/achievements/${id}`));
};

export const subscribeToAchievements = (callback: (achievements: Achievement[]) => void) => {
    if (!db) return () => {};
    const refAch = ref(db, 'system_settings/achievements');
    onValue(refAch, (snapshot) => {
        const data = snapshot.val();
        callback(data ? Object.keys(data).map(k => ({...data[k], id: k})) : []);
    });
    return () => off(refAch, 'value');
};

export const subscribeToUserAchievements = (uid: string, callback: (data: Record<string, { isUnlocked: boolean, unlockedAt: number, progress: number }>) => void) => {
    if (!db || !uid) return () => {};
    const userAchRef = ref(db, `users/${uid}/achievements`);
    onValue(userAchRef, (snapshot) => callback(snapshot.val() || {}));
    return () => off(userAchRef, 'value');
};

export const unlockUserAchievement = async (uid: string, achId: string, progress: number = 100) => {
    if (!db || !uid) return;
    const achRef = ref(db, `users/${uid}/achievements/${achId}`);
    await update(achRef, {
        isUnlocked: progress >= 100,
        unlockedAt: progress >= 100 ? Date.now() : null,
        progress: progress
    });
};

export const restoreDefaultAchievements = async () => {
    ensureDb();
    // Lista EXATA das 5 conquistas solicitadas
    const defaults: Omit<Achievement, 'id' | 'isUnlocked'>[] = [
        { title: "Mestre das Receitas", description: "Adicione 5 receitas ao sistema.", iconName: 'Target', conditionType: 'income_count', conditionValue: 5 },
        { title: "Controlador de Gastos", description: "Adicione 5 gastos ao sistema.", iconName: 'FirstExpense', conditionType: 'expense_count', conditionValue: 5 },
        { title: "Trabalhador Honesto", description: "Adicione uma transação na categoria Salário.", iconName: 'FinanceMaster', conditionType: 'manual', conditionValue: 1 },
        { title: "Explorador Beta", description: "Use a função beta 1 vez.", iconName: 'BetaTester', conditionType: 'manual', conditionValue: 1 },
        { title: "Capitalyx AI", description: "Use a capitalyx AI uma vez.", iconName: 'BrainCircuit', conditionType: 'ai_usage', conditionValue: 1 }
    ];

    const achRef = ref(db, 'system_settings/achievements');
    
    // ATOMIC WRITE: Cria um objeto mapa para substituir tudo de uma vez
    // Isso evita que o listener dispare múltiplas vezes com lista parcial
    const updates: Record<string, any> = {};
    
    defaults.forEach(ach => {
        // Gera chave localmente
        const newKey = push(achRef).key; 
        if (newKey) {
            updates[newKey] = { ...ach, id: newKey };
        }
    });

    // Substitui todo o nó de conquistas em uma única operação
    await set(achRef, updates);
};

// --- STORE / WALLET ---
export const updateStoreBalance = async (uid: string, balance: number): Promise<void> => {
    ensureDb();
    await update(ref(db, `users/${uid}/profile`), { storeBalance: balance });
};

export const subscribeToStoreBalance = (uid: string, callback: (balance: number) => void) => {
    if (!db || !uid) return () => {};
    const balRef = ref(db, `users/${uid}/profile/storeBalance`);
    const handler = (snapshot: DataSnapshot) => {
        const val = snapshot.val();
        callback(typeof val === 'number' ? val : 0);
    };
    onValue(balRef, handler);
    return () => off(balRef, 'value', handler);
};

// --- INTEGRITY & AI ---
export const toggleAIProvider = async (provider: AIProvider, uid: string) => {
    ensureDb();
    await update(ref(db, 'system_settings/ai_config'), {
        activeProvider: provider,
        lastChanged: Date.now(),
        changedBy: uid
    });
};

export const getAIConfig = async (): Promise<AIConfig> => {
    if (!db) return { activeProvider: 'gemini', lastChanged: 0, changedBy: 'system' };
    try {
        const snap = await get(ref(db, 'system_settings/ai_config'));
        return snap.val() || { activeProvider: 'gemini' };
    } catch (e) {
        return { activeProvider: 'gemini', lastChanged: 0, changedBy: 'system' };
    }
};

export const subscribeToAIConfig = (callback: (config: AIConfig) => void) => {
    if (!db) return () => {};
    const aiConfigRef = ref(db, 'system_settings/ai_config');
    const handler = (snap: DataSnapshot) => callback(snap.val() || { activeProvider: 'gemini' });
    onValue(aiConfigRef, handler);
    return () => off(aiConfigRef, 'value', handler);
};

export const logIntegrityCheck = async (log: Omit<IntegrityLog, 'id'>) => {
    if (!db) return;
    try {
        const newRef = push(ref(db, 'system_settings/integrity_logs'));
        await set(newRef, { ...log, id: newRef.key });
    } catch (e) {}
};

export const updateIntegrityState = async (state: Partial<IntegrityState>) => {
    if (!db) return;
    try {
        await update(ref(db, 'system_settings/integrity_config'), state);
    } catch (e) {}
};

export const updateAIStats = async (tokens: number) => {
    if (!db) return;
    try {
        const statsRef = ref(db, 'system_settings/ai_stats');
        const snap = await get(statsRef);
        const current = snap.val() || { totalRequests: 0, totalTokensProcessed: 0 };
        await update(statsRef, {
            totalRequests: (current.totalRequests || 0) + 1,
            totalTokensProcessed: (current.totalTokensProcessed || 0) + tokens,
            lastRequestTime: Date.now()
        });
    } catch (e) {}
};

export const restartAIServices = async () => {
    ensureDb();
    await update(ref(db, 'system_settings/integrity_config'), {
        checkCount: 0,
        isPaused: false,
        status: 'idle',
        forceCheckTrigger: Date.now()
    });
};

export const forceIntegrityCheck = async () => {
    ensureDb();
    await update(ref(db, 'system_settings/integrity_config'), { forceCheckTrigger: Date.now(), isPaused: false });
};

export const subscribeToIntegrityLogs = (callback: (logs: IntegrityLog[]) => void) => {
    if (!db) return () => {};
    const logsRef = ref(db, 'system_settings/integrity_logs');
    const handler = (snap: DataSnapshot) => {
        const data = snap.val();
        const parsed = data ? Object.keys(data).map(k => ({...data[k], id: k})) : [];
        callback(parsed.sort((a, b) => b.timestamp - a.timestamp));
    };
    onValue(logsRef, handler);
    return () => off(logsRef, 'value', handler);
};

export const subscribeToIntegrityConfig = (callback: (config: IntegrityState) => void) => {
    if (!db) return () => {};
    const configRef = ref(db, 'system_settings/integrity_config');
    const handler = (snap: DataSnapshot) => callback(snap.val() || {});
    onValue(configRef, handler);
    return () => off(configRef, 'value', handler);
};

export const subscribeToAIStats = (callback: (stats: AIUsageStats) => void) => {
    if (!db) return () => {};
    const statsRef = ref(db, 'system_settings/ai_stats');
    const handler = (snap: DataSnapshot) => callback(snap.val() || {});
    onValue(statsRef, handler);
    return () => off(statsRef, 'value', handler);
};

// --- System Configuration & Maintenance ---
export const toggleSystemMaintenance = async (uid: string, status: boolean): Promise<void> => {
  ensureDb();
  await update(ref(db, 'system_settings/config'), { maintenanceMode: status, lastUpdated: Date.now(), updatedBy: uid });
};

export const toggleGlobalBetaMode = async (uid: string, status: boolean): Promise<void> => {
    ensureDb();
    await update(ref(db, 'system_settings/config'), { forceGlobalBeta: status, lastUpdated: Date.now(), updatedBy: uid });
};

export const performSystemFactoryReset = async (uid: string): Promise<void> => {
    ensureDb();
    await remove(ref(db, 'users'));
    await remove(ref(db, 'login_codes'));
    await remove(ref(db, 'system_settings/integrity_logs'));
    await remove(ref(db, 'system_settings/ai_stats'));
    await set(ref(db, 'system_settings/config'), { maintenanceMode: false, lastUpdated: Date.now(), updatedBy: 'SYSTEM_RESET' });
};

export const applySystemPatch = async (version: string, updatedBy: string): Promise<void> => {
    ensureDb();
    await update(ref(db, 'system_settings/config'), { activePatchVersion: version, lastUpdated: Date.now(), updatedBy });
};

export const subscribeToSystemStatus = (callback: (config: SystemConfig) => void) => {
  if (!db) return () => {};
  const sysRef = ref(db, 'system_settings/config');
  const handler = (snapshot: DataSnapshot) => callback(snapshot.val() || { maintenanceMode: false, lastUpdated: 0, updatedBy: 'system' });
  onValue(sysRef, handler);
  return () => off(sysRef, 'value', handler);
};

// --- Transactions ---
export const addTransaction = async (uid: string, transaction: Omit<Transaction, 'id'>): Promise<void> => {
  ensureDb();
  const newRef = push(ref(db, `users/${uid}/transactions`));
  await set(newRef, { ...transaction, id: newRef.key });
};

export const deleteTransaction = async (uid: string, transactionId: string): Promise<void> => {
  ensureDb();
  await remove(ref(db, `users/${uid}/transactions/${transactionId}`));
};

export const subscribeToTransactions = (uid: string, callback: (data: Transaction[]) => void) => {
  if (!db || !uid) return () => {};
  const q = ref(db, `users/${uid}/transactions`);
  const handler = (snapshot: DataSnapshot) => {
    const data = snapshot.val();
    const parsedData: Transaction[] = data ? Object.keys(data).map(k => ({ ...data[k], id: k })) : [];
    callback(parsedData.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
  };
  onValue(q, handler);
  return () => off(q, 'value', handler);
};

export const addRecurringTransaction = async (uid: string, item: Omit<RecurringTransaction, 'id'>) => {
    ensureDb();
    const newRef = push(ref(db, `users/${uid}/beta/recurring`));
    await set(newRef, { ...item, id: newRef.key });
};

export const subscribeToRecurringTransactions = (uid: string, callback: (data: RecurringTransaction[]) => void) => {
    if (!db || !uid) return () => {};
    const q = ref(db, `users/${uid}/beta/recurring`);
    const handler = (snap: DataSnapshot) => {
        const data = snap.val();
        callback(data ? Object.keys(data).map(k => ({...data[k], id: k})) : []);
    };
    onValue(q, handler);
    return () => off(q, 'value', handler);
};

export const deleteRecurringTransaction = async (uid: string, id: string) => {
    ensureDb();
    await remove(ref(db, `users/${uid}/beta/recurring/${id}`));
};

export const addCustomCategory = async (uid: string, category: string) => {
    ensureDb();
    const newRef = push(ref(db, `users/${uid}/beta/custom_categories`));
    await set(newRef, category);
};

export const subscribeToCustomCategories = (uid: string, callback: (cats: string[]) => void) => {
    if (!db || !uid) return () => {};
    const q = ref(db, `users/${uid}/beta/custom_categories`);
    const handler = (snap: DataSnapshot) => callback(snap.val() ? Object.values(snap.val()) : []);
    onValue(q, handler);
    return () => off(q, 'value', handler);
};

// --- Goals ---
export const addGoal = async (uid: string, goal: Omit<FinancialGoal, 'id'>) => {
  ensureDb();
  const newRef = push(ref(db, `users/${uid}/goals`));
  await set(newRef, { ...goal, id: newRef.key, createdAt: Date.now() });
};

export const updateGoal = async (uid: string, goalId: string, updates: Partial<FinancialGoal>) => {
  ensureDb();
  await update(ref(db, `users/${uid}/goals/${goalId}`), updates);
};

export const deleteGoal = async (uid: string, goalId: string) => {
  ensureDb();
  await remove(ref(db, `users/${uid}/goals/${goalId}`));
};

export const subscribeToGoals = (uid: string, callback: (data: FinancialGoal[]) => void) => {
  if (!db || !uid) return () => {};
  const q = ref(db, `users/${uid}/goals`);
  const handler = (snapshot: DataSnapshot) => {
    const data = snapshot.val();
    callback(data ? Object.keys(data).map(k => ({ ...data[k], id: k })) : []);
  };
  onValue(q, handler);
  return () => off(q, 'value', handler);
};

// --- Stats ---
export const markAIUsage = async (uid: string) => {
  if (!db || !uid) return;
  const statsRef = ref(db, `users/${uid}/stats`);
  const snap = await get(statsRef);
  const current = snap.val() || {};
  await update(statsRef, { 
    hasUsedAI: true, 
    lastAnalysisDate: Date.now(),
    aiUsageCount: (current.aiUsageCount || 0) + 1 
  });
};

export const updateUserStats = async (uid: string, stats: Partial<UserStats>) => {
    if (!db || !uid) return;
    await update(ref(db, `users/${uid}/stats`), sanitizedStats(stats));
};

const sanitizedStats = (stats: any) => {
    return Object.fromEntries(Object.entries(stats).filter(([_, v]) => v !== undefined));
};

export const subscribeToStats = (uid: string, callback: (stats: UserStats) => void) => {
  if (!db || !uid) return () => {};
  const q = ref(db, `users/${uid}/stats`);
  const handler = (snapshot: DataSnapshot) => callback(snapshot.val() || {});
  onValue(q, handler);
  return () => off(q, 'value', handler);
};
