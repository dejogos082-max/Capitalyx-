
import { AIAnalysisResult } from "../types";

// Chave de fallback caso a env não esteja configurada
const CLIENT_API_KEY = "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";
const API_URL = "https://api.openai.com/v1/chat/completions";

export interface OpenAIMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

const cleanJsonString = (rawString: string): string => {
  let cleaned = rawString.trim();
  const jsonBlockRegex = /```(?:json)?\s*([\s\S]*?)\s*```/i;
  const match = cleaned.match(jsonBlockRegex);
  if (match && match[1]) { cleaned = match[1].trim(); }
  if (!match) {
      cleaned = cleaned.replace(/^```json/, "").replace(/```$/, "").trim();
  }
  return cleaned;
};

export const OpenAIConfig = {
  getApiKey: () => {
    // Verifica se a env existe e não é a string "undefined" (comum no Vite/ESM)
    const envKey = process.env.OPENAI_API_KEY;
    if (envKey && envKey !== 'undefined' && envKey.length > 10) return envKey;
    return CLIENT_API_KEY;
  },

  execute: async (messages: OpenAIMessage[]) => {
    const apiKey = OpenAIConfig.getApiKey();
    
    try {
      const payload = {
        model: "gpt-4o-mini",
        messages: messages,
        temperature: 0.2, 
        max_tokens: 1500,
        response_format: { type: "json_object" }
      };

      const response = await fetch(API_URL, {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${apiKey}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify(payload)
      });

      if (!response.ok) {
        const errorText = await response.text();
        let errorData;
        try { errorData = JSON.parse(errorText); } catch(e) { errorData = { error: { message: errorText } }; }

        if (response.status === 429) throw new Error("OPENAI_QUOTA_EXCEEDED");
        if (response.status === 401) throw new Error("OPENAI_AUTH_FAILED");
        
        throw new Error(`OpenAI Error (${response.status}): ${errorData.error?.message || 'Erro desconhecido'}`);
      }

      return await response.json();
    } catch (e: any) {
      console.error("[OpenAIService] Request Failed:", e.message);
      throw e;
    }
  },

  generateAnalysis: async (prompt: string): Promise<AIAnalysisResult> => {
      const messages: OpenAIMessage[] = [
          { role: "system", content: "Você é um analista financeiro de elite. Responda estritamente em JSON no formato solicitado. Seja conciso e estratégico." },
          { role: "user", content: prompt }
      ];

      try {
          const data = await OpenAIConfig.execute(messages);
          const content = data.choices?.[0]?.message?.content;
          if (!content) throw new Error("Resposta do OpenAI veio vazia.");
          
          const cleaned = cleanJsonString(content);
          const parsed = JSON.parse(cleaned);
          
          return { 
              ...parsed, 
              providerUsed: 'openai',
              analyzedAt: Date.now() 
          };
      } catch (e: any) {
          throw e; // Lança para o orquestrador tratar o fallback
      }
  }
};
