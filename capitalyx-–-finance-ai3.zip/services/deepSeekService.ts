import { AIAnalysisResult } from "../types";

// --- DeepSeek API Integration Core ---
// Status: Conditional Active (Controlled by Admin Panel)

const API_KEY = "sk-119dc44dd87741b48a174fa5a611092b";
const API_URL = "https://api.deepseek.com/v1/chat/completions";

export interface DeepSeekMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

// Helper para limpar JSON
const cleanJsonString = (rawString: string): string => {
  let cleaned = rawString.trim();
  if (cleaned.startsWith('```json')) {
    cleaned = cleaned.replace(/^```json/, '').replace(/```$/, '');
  } else if (cleaned.startsWith('```')) {
    cleaned = cleaned.replace(/^```/, '').replace(/```$/, '');
  }
  return cleaned.trim();
};

export const DeepSeekConfig = {
  
  execute: async (messages: DeepSeekMessage[]) => {
    try {
      const payload = {
        model: "deepseek-chat",
        messages: messages,
        temperature: 0.3, 
        max_tokens: 1000,
        response_format: { type: "json_object" } 
      };

      const response = await fetch(API_URL, {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${API_KEY}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify(payload)
      });

      if (!response.ok) {
        const errorText = await response.text();
        
        // Trata erro de saldo de forma específica
        if (response.status === 402) {
             throw new Error("DEEPSEEK_QUOTA_EXCEEDED");
        }

        throw new Error(`DeepSeek API Error: ${response.status} - ${errorText}`);
      }

      const data = await response.json();
      return data;

    } catch (e: any) {
      // Re-throw para o orquestrador capturar
      throw e;
    }
  },

  generateAnalysis: async (prompt: string): Promise<AIAnalysisResult> => {
      const messages: DeepSeekMessage[] = [
          {
              role: "system",
              content: "Você é um analista financeiro. Responda APENAS com um JSON válido seguindo estritamente o esquema solicitado. Não inclua texto fora do JSON."
          },
          {
              role: "user",
              content: prompt
          }
      ];

      const data = await DeepSeekConfig.execute(messages);
      const content = data.choices?.[0]?.message?.content;
      
      if (!content) throw new Error("DeepSeek retornou resposta vazia.");

      const cleaned = cleanJsonString(content);
      const result = JSON.parse(cleaned) as AIAnalysisResult;
      
      return { ...result, analyzedAt: Date.now() };
  }
};