
// --- DeepSeek Analysis Logic ---
// Handles formatting and parsing specific to DeepSeek for AI Monitor

import { DeepSeekConfig, DeepSeekMessage } from "./deepSeekService";

interface DeepSeekAnalysisResponse {
    status: 'ok' | 'warning' | 'error';
    summary: string;
}

export const runDeepSeekSystemAnalysis = async (metrics: any): Promise<DeepSeekAnalysisResponse> => {
    
    // Prompt Otimizado para DeepSeek (mais conciso que o do Gemini)
    const messages: DeepSeekMessage[] = [
        {
            role: "system",
            content: "Você é o 'Capitalyx Sentinel' (DeepSeek Engine). Analise JSON de métricas do servidor. Responda ESTRITAMENTE no formato: [STATUS] Resumo. Status possíveis: HEALTHY, WARNING, CRITICAL."
        },
        {
            role: "user",
            content: `Analise estas métricas reais: ${JSON.stringify(metrics)}. Regras: Offline=CRITICAL, Memoria>500MB=WARNING. Caso contrário HEALTHY.`
        }
    ];

    try {
        const result = await DeepSeekConfig.execute(messages);
        const rawContent = result.choices?.[0]?.message?.content || "";
        
        // Parse da resposta (Logica customizada para DeepSeek que pode ser mais verborrágico)
        let status: 'ok' | 'warning' | 'error' = 'ok';
        if (rawContent.includes("CRITICAL")) status = 'error';
        else if (rawContent.includes("WARNING")) status = 'warning';

        // Limpeza simples da string
        const summary = rawContent.replace(/\[.*?\]/g, '').trim() || "Análise DeepSeek concluída.";

        return { status, summary };

    } catch (error) {
        console.error("[DeepSeekAnalysis] Falha na análise:", error);
        throw error;
    }
};
